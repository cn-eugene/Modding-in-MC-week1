
package net.mcreator.alexawad.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.BlockPos;

public class GODBLOCKBlock extends Block {
	public GODBLOCKBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.GRAVEL).strength(64000f, 999999999f).requiresCorrectToolForDrops().friction(4.3f).speedFactor(1000f).jumpFactor(1000f));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}

	@Override
	public boolean canBeReplaced(BlockState state, BlockPlaceContext context) {
		return context.getItemInHand().getItem() != this.asItem();
	}
}
