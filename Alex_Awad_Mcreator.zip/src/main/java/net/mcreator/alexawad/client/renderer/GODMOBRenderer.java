
package net.mcreator.alexawad.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.alexawad.entity.GODMOBEntity;

public class GODMOBRenderer extends HumanoidMobRenderer<GODMOBEntity, HumanoidModel<GODMOBEntity>> {
	public GODMOBRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(GODMOBEntity entity) {
		return new ResourceLocation("alex_awad_:textures/entities/e9aac27538b99a87a23af86bf932a59e64dbb06b.png");
	}
}
