
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexawad.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.alexawad.block.WBOREBlock;
import net.mcreator.alexawad.block.GODMENSIONPortalBlock;
import net.mcreator.alexawad.block.GODBLOCKBlock;
import net.mcreator.alexawad.AlexAwadMod;

public class AlexAwadModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AlexAwadMod.MODID);
	public static final RegistryObject<Block> GODBLOCK = REGISTRY.register("godblock", () -> new GODBLOCKBlock());
	public static final RegistryObject<Block> WBORE = REGISTRY.register("wbore", () -> new WBOREBlock());
	public static final RegistryObject<Block> GODMENSION_PORTAL = REGISTRY.register("godmension_portal", () -> new GODMENSIONPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
