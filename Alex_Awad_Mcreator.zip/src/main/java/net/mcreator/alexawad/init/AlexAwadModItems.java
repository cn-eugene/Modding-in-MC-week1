
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexawad.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.alexawad.item.OPItem;
import net.mcreator.alexawad.item.NUCLEARBOMBItem;
import net.mcreator.alexawad.item.GODSWORD01Item;
import net.mcreator.alexawad.item.GODSHOVELItem;
import net.mcreator.alexawad.item.GODPICKAXEItem;
import net.mcreator.alexawad.item.GODMENSIONItem;
import net.mcreator.alexawad.item.GODHOEItem;
import net.mcreator.alexawad.item.GODAXEItem;
import net.mcreator.alexawad.item.GODARMORItem;
import net.mcreator.alexawad.item.GODAPPLEItem;
import net.mcreator.alexawad.AlexAwadMod;

public class AlexAwadModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AlexAwadMod.MODID);
	public static final RegistryObject<Item> GODBLOCK = block(AlexAwadModBlocks.GODBLOCK);
	public static final RegistryObject<Item> OP = REGISTRY.register("op", () -> new OPItem());
	public static final RegistryObject<Item> WBORE = block(AlexAwadModBlocks.WBORE);
	public static final RegistryObject<Item> GODARMOR_HELMET = REGISTRY.register("godarmor_helmet", () -> new GODARMORItem.Helmet());
	public static final RegistryObject<Item> GODARMOR_CHESTPLATE = REGISTRY.register("godarmor_chestplate", () -> new GODARMORItem.Chestplate());
	public static final RegistryObject<Item> GODARMOR_LEGGINGS = REGISTRY.register("godarmor_leggings", () -> new GODARMORItem.Leggings());
	public static final RegistryObject<Item> GODARMOR_BOOTS = REGISTRY.register("godarmor_boots", () -> new GODARMORItem.Boots());
	public static final RegistryObject<Item> GODSWORD_01 = REGISTRY.register("godsword_01", () -> new GODSWORD01Item());
	public static final RegistryObject<Item> GODPICKAXE = REGISTRY.register("godpickaxe", () -> new GODPICKAXEItem());
	public static final RegistryObject<Item> GODAPPLE = REGISTRY.register("godapple", () -> new GODAPPLEItem());
	public static final RegistryObject<Item> GODHOE = REGISTRY.register("godhoe", () -> new GODHOEItem());
	public static final RegistryObject<Item> GODSHOVEL = REGISTRY.register("godshovel", () -> new GODSHOVELItem());
	public static final RegistryObject<Item> GODAXE = REGISTRY.register("godaxe", () -> new GODAXEItem());
	public static final RegistryObject<Item> NUCLEARBOMB = REGISTRY.register("nuclearbomb", () -> new NUCLEARBOMBItem());
	public static final RegistryObject<Item> GODMOB_SPAWN_EGG = REGISTRY.register("godmob_spawn_egg", () -> new ForgeSpawnEggItem(AlexAwadModEntities.GODMOB, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> GODMENSION = REGISTRY.register("godmension", () -> new GODMENSIONItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
