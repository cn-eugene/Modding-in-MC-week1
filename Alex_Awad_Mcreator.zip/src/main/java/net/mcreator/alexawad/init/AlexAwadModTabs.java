
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alexawad.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.alexawad.AlexAwadMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AlexAwadModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AlexAwadMod.MODID);
	public static final RegistryObject<CreativeModeTab> GOD = REGISTRY.register("god",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.alex_awad_.god")).icon(() -> new ItemStack(AlexAwadModBlocks.GODBLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(AlexAwadModItems.OP.get());
				tabData.accept(AlexAwadModBlocks.GODBLOCK.get().asItem());
				tabData.accept(AlexAwadModBlocks.WBORE.get().asItem());
				tabData.accept(AlexAwadModItems.GODARMOR_HELMET.get());
				tabData.accept(AlexAwadModItems.GODARMOR_CHESTPLATE.get());
				tabData.accept(AlexAwadModItems.GODARMOR_LEGGINGS.get());
				tabData.accept(AlexAwadModItems.GODARMOR_BOOTS.get());
				tabData.accept(AlexAwadModItems.GODSWORD_01.get());
				tabData.accept(AlexAwadModItems.GODPICKAXE.get());
				tabData.accept(AlexAwadModItems.GODAPPLE.get());
				tabData.accept(AlexAwadModItems.GODHOE.get());
				tabData.accept(AlexAwadModItems.GODSHOVEL.get());
				tabData.accept(AlexAwadModItems.GODAXE.get());
				tabData.accept(AlexAwadModItems.NUCLEARBOMB.get());
				tabData.accept(AlexAwadModItems.GODMENSION.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AlexAwadModItems.GODMOB_SPAWN_EGG.get());
		}
	}
}
