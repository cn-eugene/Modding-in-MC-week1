
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.frankie.item.SilveringotItem;
import net.mcreator.frankie.item.KnifeItem;
import net.mcreator.frankie.item.FortressItem;
import net.mcreator.frankie.FrankieMod;

public class FrankieModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FrankieMod.MODID);
	public static final RegistryObject<Item> AMOGUS = block(FrankieModBlocks.AMOGUS);
	public static final RegistryObject<Item> SILVERORE = block(FrankieModBlocks.SILVERORE);
	public static final RegistryObject<Item> SILVERINGOT = REGISTRY.register("silveringot", () -> new SilveringotItem());
	public static final RegistryObject<Item> KNIFE = REGISTRY.register("knife", () -> new KnifeItem());
	public static final RegistryObject<Item> BLOODIEDSTONE = block(FrankieModBlocks.BLOODIEDSTONE);
	public static final RegistryObject<Item> CHARA_SPAWN_EGG = REGISTRY.register("chara_spawn_egg", () -> new ForgeSpawnEggItem(FrankieModEntities.CHARA, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> CHARA_2_SPAWN_EGG = REGISTRY.register("chara_2_spawn_egg", () -> new ForgeSpawnEggItem(FrankieModEntities.CHARA_2, -3407872, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> FORTRESS_HELMET = REGISTRY.register("fortress_helmet", () -> new FortressItem.Helmet());
	public static final RegistryObject<Item> FORTRESS_CHESTPLATE = REGISTRY.register("fortress_chestplate", () -> new FortressItem.Chestplate());
	public static final RegistryObject<Item> FORTRESS_LEGGINGS = REGISTRY.register("fortress_leggings", () -> new FortressItem.Leggings());
	public static final RegistryObject<Item> FORTRESS_BOOTS = REGISTRY.register("fortress_boots", () -> new FortressItem.Boots());
	public static final RegistryObject<Item> AMOGUS_2 = block(FrankieModBlocks.AMOGUS_2);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
