
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankie.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.frankie.client.renderer.CharaRenderer;
import net.mcreator.frankie.client.renderer.Chara2Renderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class FrankieModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(FrankieModEntities.CHARA.get(), CharaRenderer::new);
		event.registerEntityRenderer(FrankieModEntities.CHARA_2.get(), Chara2Renderer::new);
	}
}
