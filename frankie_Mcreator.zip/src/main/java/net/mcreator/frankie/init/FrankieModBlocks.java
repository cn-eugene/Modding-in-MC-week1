
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.frankie.block.SilveroreBlock;
import net.mcreator.frankie.block.BloodiedstoneBlock;
import net.mcreator.frankie.block.AmogusBlock;
import net.mcreator.frankie.block.Amogus2Block;
import net.mcreator.frankie.FrankieMod;

public class FrankieModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FrankieMod.MODID);
	public static final RegistryObject<Block> AMOGUS = REGISTRY.register("amogus", () -> new AmogusBlock());
	public static final RegistryObject<Block> SILVERORE = REGISTRY.register("silverore", () -> new SilveroreBlock());
	public static final RegistryObject<Block> BLOODIEDSTONE = REGISTRY.register("bloodiedstone", () -> new BloodiedstoneBlock());
	public static final RegistryObject<Block> AMOGUS_2 = REGISTRY.register("amogus_2", () -> new Amogus2Block());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			AmogusBlock.blockColorLoad(event);
		}
	}
}
