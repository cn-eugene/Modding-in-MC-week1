
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankie.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.frankie.entity.CharaEntity;
import net.mcreator.frankie.entity.Chara2Entity;
import net.mcreator.frankie.FrankieMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class FrankieModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FrankieMod.MODID);
	public static final RegistryObject<EntityType<CharaEntity>> CHARA = register("chara",
			EntityType.Builder.<CharaEntity>of(CharaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CharaEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<Chara2Entity>> CHARA_2 = register("chara_2",
			EntityType.Builder.<Chara2Entity>of(Chara2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Chara2Entity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			CharaEntity.init();
			Chara2Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(CHARA.get(), CharaEntity.createAttributes().build());
		event.put(CHARA_2.get(), Chara2Entity.createAttributes().build());
	}
}
