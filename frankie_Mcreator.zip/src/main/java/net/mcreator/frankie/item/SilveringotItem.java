
package net.mcreator.frankie.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SilveringotItem extends Item {
	public SilveringotItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
