package net.mcreator.elliottmayorga.procedures;

public class SniperSpecialInformationProcedure {
	public static void execute() {
	}
}
