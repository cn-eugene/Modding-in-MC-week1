
package net.mcreator.elliottmayorga.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.elliottmayorga.entity.StormtrooperEntity;

public class StormtrooperRenderer extends HumanoidMobRenderer<StormtrooperEntity, HumanoidModel<StormtrooperEntity>> {
	public StormtrooperRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(StormtrooperEntity entity) {
		return new ResourceLocation("elliott_mayorga:textures/entities/ba2bb8a0ec0dcab621ac93779ef873129382f3f8.png");
	}
}
