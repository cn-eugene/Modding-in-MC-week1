
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elliottmayorga.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.elliottmayorga.client.renderer.StormtrooperRenderer;
import net.mcreator.elliottmayorga.client.renderer.NothingRenderer;
import net.mcreator.elliottmayorga.client.renderer.JelloRenderer;
import net.mcreator.elliottmayorga.client.renderer.EndersoldierRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ElliottMayorgaModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ElliottMayorgaModEntities.BULLET.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ElliottMayorgaModEntities.ENDERSOLDIER.get(), EndersoldierRenderer::new);
		event.registerEntityRenderer(ElliottMayorgaModEntities.JELLO.get(), JelloRenderer::new);
		event.registerEntityRenderer(ElliottMayorgaModEntities.STORMTROOPER.get(), StormtrooperRenderer::new);
		event.registerEntityRenderer(ElliottMayorgaModEntities.STORMTROOPER_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ElliottMayorgaModEntities.NOTHING.get(), NothingRenderer::new);
	}
}
