
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elliottmayorga.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.elliottmayorga.block.SuddenDeathBlock;
import net.mcreator.elliottmayorga.block.BombBlock;
import net.mcreator.elliottmayorga.ElliottMayorgaMod;

public class ElliottMayorgaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ElliottMayorgaMod.MODID);
	public static final RegistryObject<Block> SUDDEN_DEATH = REGISTRY.register("sudden_death", () -> new SuddenDeathBlock());
	public static final RegistryObject<Block> BOMB = REGISTRY.register("bomb", () -> new BombBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
