
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elliottmayorga.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.elliottmayorga.ElliottMayorgaMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ElliottMayorgaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ElliottMayorgaMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ElliottMayorgaModItems.GUN.get());
			tabData.accept(ElliottMayorgaModItems.GUNSWORD.get());
			tabData.accept(ElliottMayorgaModItems.ARMOROFPSY_HELMET.get());
			tabData.accept(ElliottMayorgaModItems.ARMOROFPSY_CHESTPLATE.get());
			tabData.accept(ElliottMayorgaModItems.ARMOROFPSY_LEGGINGS.get());
			tabData.accept(ElliottMayorgaModItems.ARMOROFPSY_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ElliottMayorgaModItems.ENDERSOLDIER_SPAWN_EGG.get());
			tabData.accept(ElliottMayorgaModItems.JELLO_SPAWN_EGG.get());
			tabData.accept(ElliottMayorgaModItems.STORMTROOPER_SPAWN_EGG.get());
			tabData.accept(ElliottMayorgaModItems.NOTHING_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ElliottMayorgaModBlocks.SUDDEN_DEATH.get().asItem());
			tabData.accept(ElliottMayorgaModBlocks.BOMB.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ElliottMayorgaModItems.SLICER.get());
		}
	}
}
