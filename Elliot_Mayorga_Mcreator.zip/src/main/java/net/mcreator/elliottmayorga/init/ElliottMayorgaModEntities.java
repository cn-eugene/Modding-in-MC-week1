
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elliottmayorga.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.elliottmayorga.entity.StormtrooperEntityProjectile;
import net.mcreator.elliottmayorga.entity.StormtrooperEntity;
import net.mcreator.elliottmayorga.entity.NothingEntity;
import net.mcreator.elliottmayorga.entity.JelloEntity;
import net.mcreator.elliottmayorga.entity.EndersoldierEntity;
import net.mcreator.elliottmayorga.entity.BulletEntity;
import net.mcreator.elliottmayorga.ElliottMayorgaMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ElliottMayorgaModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ElliottMayorgaMod.MODID);
	public static final RegistryObject<EntityType<BulletEntity>> BULLET = register("bullet",
			EntityType.Builder.<BulletEntity>of(BulletEntity::new, MobCategory.MISC).setCustomClientFactory(BulletEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<EndersoldierEntity>> ENDERSOLDIER = register("endersoldier",
			EntityType.Builder.<EndersoldierEntity>of(EndersoldierEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EndersoldierEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<JelloEntity>> JELLO = register("jello",
			EntityType.Builder.<JelloEntity>of(JelloEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(JelloEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<StormtrooperEntity>> STORMTROOPER = register("stormtrooper",
			EntityType.Builder.<StormtrooperEntity>of(StormtrooperEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(StormtrooperEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<StormtrooperEntityProjectile>> STORMTROOPER_PROJECTILE = register("projectile_stormtrooper", EntityType.Builder.<StormtrooperEntityProjectile>of(StormtrooperEntityProjectile::new, MobCategory.MISC)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(StormtrooperEntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<NothingEntity>> NOTHING = register("nothing",
			EntityType.Builder.<NothingEntity>of(NothingEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(NothingEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			EndersoldierEntity.init();
			JelloEntity.init();
			StormtrooperEntity.init();
			NothingEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ENDERSOLDIER.get(), EndersoldierEntity.createAttributes().build());
		event.put(JELLO.get(), JelloEntity.createAttributes().build());
		event.put(STORMTROOPER.get(), StormtrooperEntity.createAttributes().build());
		event.put(NOTHING.get(), NothingEntity.createAttributes().build());
	}
}
