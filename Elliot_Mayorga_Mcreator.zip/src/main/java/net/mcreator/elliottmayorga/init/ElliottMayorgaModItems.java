
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elliottmayorga.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.elliottmayorga.item.SniperItem;
import net.mcreator.elliottmayorga.item.SlicerItem;
import net.mcreator.elliottmayorga.item.GunswordItem;
import net.mcreator.elliottmayorga.item.GunItem;
import net.mcreator.elliottmayorga.item.ARMOROFPSYItem;
import net.mcreator.elliottmayorga.ElliottMayorgaMod;

public class ElliottMayorgaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ElliottMayorgaMod.MODID);
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());
	public static final RegistryObject<Item> SUDDEN_DEATH = block(ElliottMayorgaModBlocks.SUDDEN_DEATH);
	public static final RegistryObject<Item> GUNSWORD = REGISTRY.register("gunsword", () -> new GunswordItem());
	public static final RegistryObject<Item> BOMB = block(ElliottMayorgaModBlocks.BOMB);
	public static final RegistryObject<Item> ARMOROFPSY_HELMET = REGISTRY.register("armorofpsy_helmet", () -> new ARMOROFPSYItem.Helmet());
	public static final RegistryObject<Item> ARMOROFPSY_CHESTPLATE = REGISTRY.register("armorofpsy_chestplate", () -> new ARMOROFPSYItem.Chestplate());
	public static final RegistryObject<Item> ARMOROFPSY_LEGGINGS = REGISTRY.register("armorofpsy_leggings", () -> new ARMOROFPSYItem.Leggings());
	public static final RegistryObject<Item> ARMOROFPSY_BOOTS = REGISTRY.register("armorofpsy_boots", () -> new ARMOROFPSYItem.Boots());
	public static final RegistryObject<Item> SLICER = REGISTRY.register("slicer", () -> new SlicerItem());
	public static final RegistryObject<Item> ENDERSOLDIER_SPAWN_EGG = REGISTRY.register("endersoldier_spawn_egg", () -> new ForgeSpawnEggItem(ElliottMayorgaModEntities.ENDERSOLDIER, -16777216, -52429, new Item.Properties()));
	public static final RegistryObject<Item> SNIPER = REGISTRY.register("sniper", () -> new SniperItem());
	public static final RegistryObject<Item> JELLO_SPAWN_EGG = REGISTRY.register("jello_spawn_egg", () -> new ForgeSpawnEggItem(ElliottMayorgaModEntities.JELLO, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> STORMTROOPER_SPAWN_EGG = REGISTRY.register("stormtrooper_spawn_egg", () -> new ForgeSpawnEggItem(ElliottMayorgaModEntities.STORMTROOPER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> NOTHING_SPAWN_EGG = REGISTRY.register("nothing_spawn_egg", () -> new ForgeSpawnEggItem(ElliottMayorgaModEntities.NOTHING, -16777216, -16777216, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
