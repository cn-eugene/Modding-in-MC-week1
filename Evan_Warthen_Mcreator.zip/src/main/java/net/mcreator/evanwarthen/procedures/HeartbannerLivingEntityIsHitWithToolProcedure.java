package net.mcreator.evanwarthen.procedures;

import net.minecraft.world.entity.Entity;

public class HeartbannerLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(20);
	}
}
