
package net.mcreator.evanwarthen.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.evanwarthen.init.EvanwarthenModItems;
import net.mcreator.evanwarthen.init.EvanwarthenModFluids;
import net.mcreator.evanwarthen.init.EvanwarthenModFluidTypes;
import net.mcreator.evanwarthen.init.EvanwarthenModBlocks;

public abstract class EjgfFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> EvanwarthenModFluidTypes.EJGF_TYPE.get(), () -> EvanwarthenModFluids.EJGF.get(), () -> EvanwarthenModFluids.FLOWING_EJGF.get())
			.explosionResistance(100f).tickRate(10).slopeFindDistance(10).bucket(() -> EvanwarthenModItems.EJGF_BUCKET.get()).block(() -> (LiquidBlock) EvanwarthenModBlocks.EJGF.get());

	private EjgfFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.INSTANT_EFFECT;
	}

	public static class Source extends EjgfFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends EjgfFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
