
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.evanwarthen.block.RetukPortalBlock;
import net.mcreator.evanwarthen.block.REDOreBlock;
import net.mcreator.evanwarthen.block.REDBlockBlock;
import net.mcreator.evanwarthen.block.EjgfBlock;
import net.mcreator.evanwarthen.block.DsaPortalBlock;
import net.mcreator.evanwarthen.block.CloulddenPortalBlock;
import net.mcreator.evanwarthen.block.ClouddenPortalBlock;
import net.mcreator.evanwarthen.block.BLUEOreBlock;
import net.mcreator.evanwarthen.block.BLUEBlockBlock;
import net.mcreator.evanwarthen.EvanwarthenMod;

public class EvanwarthenModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EvanwarthenMod.MODID);
	public static final RegistryObject<Block> RED_ORE = REGISTRY.register("red_ore", () -> new REDOreBlock());
	public static final RegistryObject<Block> RED_BLOCK = REGISTRY.register("red_block", () -> new REDBlockBlock());
	public static final RegistryObject<Block> BLUE_ORE = REGISTRY.register("blue_ore", () -> new BLUEOreBlock());
	public static final RegistryObject<Block> BLUE_BLOCK = REGISTRY.register("blue_block", () -> new BLUEBlockBlock());
	public static final RegistryObject<Block> CLOULDDEN_PORTAL = REGISTRY.register("clouldden_portal", () -> new CloulddenPortalBlock());
	public static final RegistryObject<Block> CLOUDDEN_PORTAL = REGISTRY.register("cloudden_portal", () -> new ClouddenPortalBlock());
	public static final RegistryObject<Block> RETUK_PORTAL = REGISTRY.register("retuk_portal", () -> new RetukPortalBlock());
	public static final RegistryObject<Block> EJGF = REGISTRY.register("ejgf", () -> new EjgfBlock());
	public static final RegistryObject<Block> DSA_PORTAL = REGISTRY.register("dsa_portal", () -> new DsaPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
