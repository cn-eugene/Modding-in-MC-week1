
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthen.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.evanwarthen.client.renderer.SlimemanRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EvanwarthenModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EvanwarthenModEntities.LIGHTNING.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EvanwarthenModEntities.SHUSHU.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(EvanwarthenModEntities.SLIMEMAN.get(), SlimemanRenderer::new);
		event.registerEntityRenderer(EvanwarthenModEntities.WARDEN_PROJECTILE.get(), ThrownItemRenderer::new);
	}
}
