
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.evanwarthen.EvanwarthenMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EvanwarthenModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EvanwarthenMod.MODID);
	public static final RegistryObject<CreativeModeTab> YOER = REGISTRY.register("yoer",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.evanwarthen.yoer")).icon(() -> new ItemStack(EvanwarthenModItems.YRWE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EvanwarthenModItems.UNBEATEN_AXE.get());
				tabData.accept(EvanwarthenModItems.UNBEATEN_PICKAXE.get());
				tabData.accept(EvanwarthenModItems.UNBEATEN_SWORD.get());
				tabData.accept(EvanwarthenModItems.UNBEATEN_SHOVEL.get());
				tabData.accept(EvanwarthenModItems.UNBEATEN_HOE.get());
				tabData.accept(EvanwarthenModItems.LOL_PICKAXE.get());
				tabData.accept(EvanwarthenModItems.LOL_AXE.get());
				tabData.accept(EvanwarthenModItems.LOL_SWORD.get());
				tabData.accept(EvanwarthenModItems.LOL_SHOVEL.get());
				tabData.accept(EvanwarthenModItems.LOL_HOE.get());
				tabData.accept(EvanwarthenModItems.BARRIER_PICKAXE.get());
				tabData.accept(EvanwarthenModItems.BARRIER_AXE.get());
				tabData.accept(EvanwarthenModItems.BARRIER_SWORD.get());
				tabData.accept(EvanwarthenModItems.BARRIER_SHOVEL.get());
				tabData.accept(EvanwarthenModItems.BARRIER_HOE.get());
				tabData.accept(EvanwarthenModItems.UH_PICKAXE.get());
				tabData.accept(EvanwarthenModItems.UH_AXE.get());
				tabData.accept(EvanwarthenModItems.UH_SWORD.get());
				tabData.accept(EvanwarthenModItems.UH_SHOVEL.get());
				tabData.accept(EvanwarthenModItems.UH_HOE.get());
				tabData.accept(EvanwarthenModItems.RED.get());
				tabData.accept(EvanwarthenModBlocks.RED_ORE.get().asItem());
				tabData.accept(EvanwarthenModBlocks.RED_BLOCK.get().asItem());
				tabData.accept(EvanwarthenModItems.DED_PICKAXE.get());
				tabData.accept(EvanwarthenModItems.DED_AXE.get());
				tabData.accept(EvanwarthenModItems.DED_SWORD.get());
				tabData.accept(EvanwarthenModItems.DED_SHOVEL.get());
				tabData.accept(EvanwarthenModItems.DED_HOE.get());
				tabData.accept(EvanwarthenModItems.BLUE_INGOT.get());
				tabData.accept(EvanwarthenModBlocks.BLUE_ORE.get().asItem());
				tabData.accept(EvanwarthenModBlocks.BLUE_BLOCK.get().asItem());
				tabData.accept(EvanwarthenModItems.WARDENSCEPTER.get());
				tabData.accept(EvanwarthenModItems.DISTENST_PICKAXE.get());
				tabData.accept(EvanwarthenModItems.DISTENST_AXE.get());
				tabData.accept(EvanwarthenModItems.DISTENST_SWORD.get());
				tabData.accept(EvanwarthenModItems.DISTENST_SHOVEL.get());
				tabData.accept(EvanwarthenModItems.DISTENST_HOE.get());
				tabData.accept(EvanwarthenModItems.VLUE.get());
				tabData.accept(EvanwarthenModItems.TANOS.get());
				tabData.accept(EvanwarthenModItems.HEARTBANNER.get());
				tabData.accept(EvanwarthenModItems.HEATBANNER_2.get());
				tabData.accept(EvanwarthenModItems.YRWE.get());
				tabData.accept(EvanwarthenModItems.WARDEN_BULLET.get());
				tabData.accept(EvanwarthenModItems.EJGF_BUCKET.get());
				tabData.accept(EvanwarthenModItems.DSA.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(EvanwarthenModItems.RETUK.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EvanwarthenModItems.RETYU_HELMET.get());
			tabData.accept(EvanwarthenModItems.RETYU_CHESTPLATE.get());
			tabData.accept(EvanwarthenModItems.RETYU_LEGGINGS.get());
			tabData.accept(EvanwarthenModItems.RETYU_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EvanwarthenModItems.SLIMEMAN_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(EvanwarthenModItems.CLOULDDEN.get());
			tabData.accept(EvanwarthenModItems.CLOUDDEN.get());
		}
	}
}
