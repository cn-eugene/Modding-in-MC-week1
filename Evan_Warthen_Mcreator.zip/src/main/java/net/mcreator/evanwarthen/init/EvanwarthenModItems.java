
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.evanwarthen.item.YrweItem;
import net.mcreator.evanwarthen.item.WardenscepterItem;
import net.mcreator.evanwarthen.item.WardenBulletItem;
import net.mcreator.evanwarthen.item.VlueItem;
import net.mcreator.evanwarthen.item.UnbeatenSwordItem;
import net.mcreator.evanwarthen.item.UnbeatenShovelItem;
import net.mcreator.evanwarthen.item.UnbeatenPickaxeItem;
import net.mcreator.evanwarthen.item.UnbeatenHoeItem;
import net.mcreator.evanwarthen.item.UnbeatenAxeItem;
import net.mcreator.evanwarthen.item.UhSwordItem;
import net.mcreator.evanwarthen.item.UhShovelItem;
import net.mcreator.evanwarthen.item.UhPickaxeItem;
import net.mcreator.evanwarthen.item.UhHoeItem;
import net.mcreator.evanwarthen.item.UhAxeItem;
import net.mcreator.evanwarthen.item.TanosItem;
import net.mcreator.evanwarthen.item.RetyuItem;
import net.mcreator.evanwarthen.item.RetukItem;
import net.mcreator.evanwarthen.item.REDItem;
import net.mcreator.evanwarthen.item.LolSwordItem;
import net.mcreator.evanwarthen.item.LolShovelItem;
import net.mcreator.evanwarthen.item.LolPickaxeItem;
import net.mcreator.evanwarthen.item.LolHoeItem;
import net.mcreator.evanwarthen.item.LolAxeItem;
import net.mcreator.evanwarthen.item.Heatbanner2Item;
import net.mcreator.evanwarthen.item.HeartbannerItem;
import net.mcreator.evanwarthen.item.EjgfItem;
import net.mcreator.evanwarthen.item.DsaItem;
import net.mcreator.evanwarthen.item.DistenstSwordItem;
import net.mcreator.evanwarthen.item.DistenstShovelItem;
import net.mcreator.evanwarthen.item.DistenstPickaxeItem;
import net.mcreator.evanwarthen.item.DistenstHoeItem;
import net.mcreator.evanwarthen.item.DistenstAxeItem;
import net.mcreator.evanwarthen.item.DEDSwordItem;
import net.mcreator.evanwarthen.item.DEDShovelItem;
import net.mcreator.evanwarthen.item.DEDPickaxeItem;
import net.mcreator.evanwarthen.item.DEDHoeItem;
import net.mcreator.evanwarthen.item.DEDAxeItem;
import net.mcreator.evanwarthen.item.CloulddenItem;
import net.mcreator.evanwarthen.item.ClouddenItem;
import net.mcreator.evanwarthen.item.BarrierSwordItem;
import net.mcreator.evanwarthen.item.BarrierShovelItem;
import net.mcreator.evanwarthen.item.BarrierPickaxeItem;
import net.mcreator.evanwarthen.item.BarrierHoeItem;
import net.mcreator.evanwarthen.item.BarrierAxeItem;
import net.mcreator.evanwarthen.item.BLUEIngotItem;
import net.mcreator.evanwarthen.EvanwarthenMod;

public class EvanwarthenModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EvanwarthenMod.MODID);
	public static final RegistryObject<Item> UNBEATEN_PICKAXE = REGISTRY.register("unbeaten_pickaxe", () -> new UnbeatenPickaxeItem());
	public static final RegistryObject<Item> UNBEATEN_AXE = REGISTRY.register("unbeaten_axe", () -> new UnbeatenAxeItem());
	public static final RegistryObject<Item> UNBEATEN_SWORD = REGISTRY.register("unbeaten_sword", () -> new UnbeatenSwordItem());
	public static final RegistryObject<Item> UNBEATEN_SHOVEL = REGISTRY.register("unbeaten_shovel", () -> new UnbeatenShovelItem());
	public static final RegistryObject<Item> UNBEATEN_HOE = REGISTRY.register("unbeaten_hoe", () -> new UnbeatenHoeItem());
	public static final RegistryObject<Item> LOL_PICKAXE = REGISTRY.register("lol_pickaxe", () -> new LolPickaxeItem());
	public static final RegistryObject<Item> LOL_AXE = REGISTRY.register("lol_axe", () -> new LolAxeItem());
	public static final RegistryObject<Item> LOL_SWORD = REGISTRY.register("lol_sword", () -> new LolSwordItem());
	public static final RegistryObject<Item> LOL_SHOVEL = REGISTRY.register("lol_shovel", () -> new LolShovelItem());
	public static final RegistryObject<Item> LOL_HOE = REGISTRY.register("lol_hoe", () -> new LolHoeItem());
	public static final RegistryObject<Item> BARRIER_PICKAXE = REGISTRY.register("barrier_pickaxe", () -> new BarrierPickaxeItem());
	public static final RegistryObject<Item> BARRIER_AXE = REGISTRY.register("barrier_axe", () -> new BarrierAxeItem());
	public static final RegistryObject<Item> BARRIER_SWORD = REGISTRY.register("barrier_sword", () -> new BarrierSwordItem());
	public static final RegistryObject<Item> BARRIER_SHOVEL = REGISTRY.register("barrier_shovel", () -> new BarrierShovelItem());
	public static final RegistryObject<Item> BARRIER_HOE = REGISTRY.register("barrier_hoe", () -> new BarrierHoeItem());
	public static final RegistryObject<Item> UH_PICKAXE = REGISTRY.register("uh_pickaxe", () -> new UhPickaxeItem());
	public static final RegistryObject<Item> UH_AXE = REGISTRY.register("uh_axe", () -> new UhAxeItem());
	public static final RegistryObject<Item> UH_SWORD = REGISTRY.register("uh_sword", () -> new UhSwordItem());
	public static final RegistryObject<Item> UH_SHOVEL = REGISTRY.register("uh_shovel", () -> new UhShovelItem());
	public static final RegistryObject<Item> UH_HOE = REGISTRY.register("uh_hoe", () -> new UhHoeItem());
	public static final RegistryObject<Item> RED = REGISTRY.register("red", () -> new REDItem());
	public static final RegistryObject<Item> RED_ORE = block(EvanwarthenModBlocks.RED_ORE);
	public static final RegistryObject<Item> RED_BLOCK = block(EvanwarthenModBlocks.RED_BLOCK);
	public static final RegistryObject<Item> DED_PICKAXE = REGISTRY.register("ded_pickaxe", () -> new DEDPickaxeItem());
	public static final RegistryObject<Item> DED_AXE = REGISTRY.register("ded_axe", () -> new DEDAxeItem());
	public static final RegistryObject<Item> DED_SWORD = REGISTRY.register("ded_sword", () -> new DEDSwordItem());
	public static final RegistryObject<Item> DED_SHOVEL = REGISTRY.register("ded_shovel", () -> new DEDShovelItem());
	public static final RegistryObject<Item> DED_HOE = REGISTRY.register("ded_hoe", () -> new DEDHoeItem());
	public static final RegistryObject<Item> BLUE_INGOT = REGISTRY.register("blue_ingot", () -> new BLUEIngotItem());
	public static final RegistryObject<Item> BLUE_ORE = block(EvanwarthenModBlocks.BLUE_ORE);
	public static final RegistryObject<Item> BLUE_BLOCK = block(EvanwarthenModBlocks.BLUE_BLOCK);
	public static final RegistryObject<Item> WARDENSCEPTER = REGISTRY.register("wardenscepter", () -> new WardenscepterItem());
	public static final RegistryObject<Item> DISTENST_PICKAXE = REGISTRY.register("distenst_pickaxe", () -> new DistenstPickaxeItem());
	public static final RegistryObject<Item> DISTENST_AXE = REGISTRY.register("distenst_axe", () -> new DistenstAxeItem());
	public static final RegistryObject<Item> DISTENST_SWORD = REGISTRY.register("distenst_sword", () -> new DistenstSwordItem());
	public static final RegistryObject<Item> DISTENST_SHOVEL = REGISTRY.register("distenst_shovel", () -> new DistenstShovelItem());
	public static final RegistryObject<Item> DISTENST_HOE = REGISTRY.register("distenst_hoe", () -> new DistenstHoeItem());
	public static final RegistryObject<Item> VLUE = REGISTRY.register("vlue", () -> new VlueItem());
	public static final RegistryObject<Item> TANOS = REGISTRY.register("tanos", () -> new TanosItem());
	public static final RegistryObject<Item> CLOULDDEN = REGISTRY.register("clouldden", () -> new CloulddenItem());
	public static final RegistryObject<Item> CLOUDDEN = REGISTRY.register("cloudden", () -> new ClouddenItem());
	public static final RegistryObject<Item> RETYU_HELMET = REGISTRY.register("retyu_helmet", () -> new RetyuItem.Helmet());
	public static final RegistryObject<Item> RETYU_CHESTPLATE = REGISTRY.register("retyu_chestplate", () -> new RetyuItem.Chestplate());
	public static final RegistryObject<Item> RETYU_LEGGINGS = REGISTRY.register("retyu_leggings", () -> new RetyuItem.Leggings());
	public static final RegistryObject<Item> RETYU_BOOTS = REGISTRY.register("retyu_boots", () -> new RetyuItem.Boots());
	public static final RegistryObject<Item> RETUK = REGISTRY.register("retuk", () -> new RetukItem());
	public static final RegistryObject<Item> HEARTBANNER = REGISTRY.register("heartbanner", () -> new HeartbannerItem());
	public static final RegistryObject<Item> HEATBANNER_2 = REGISTRY.register("heatbanner_2", () -> new Heatbanner2Item());
	public static final RegistryObject<Item> YRWE = REGISTRY.register("yrwe", () -> new YrweItem());
	public static final RegistryObject<Item> SLIMEMAN_SPAWN_EGG = REGISTRY.register("slimeman_spawn_egg", () -> new ForgeSpawnEggItem(EvanwarthenModEntities.SLIMEMAN, -10027162, -16724992, new Item.Properties()));
	public static final RegistryObject<Item> WARDEN_BULLET = REGISTRY.register("warden_bullet", () -> new WardenBulletItem());
	public static final RegistryObject<Item> EJGF_BUCKET = REGISTRY.register("ejgf_bucket", () -> new EjgfItem());
	public static final RegistryObject<Item> DSA = REGISTRY.register("dsa", () -> new DsaItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
