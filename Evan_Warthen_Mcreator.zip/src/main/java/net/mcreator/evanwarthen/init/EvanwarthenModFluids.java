
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.evanwarthen.fluid.EjgfFluid;
import net.mcreator.evanwarthen.EvanwarthenMod;

public class EvanwarthenModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, EvanwarthenMod.MODID);
	public static final RegistryObject<FlowingFluid> EJGF = REGISTRY.register("ejgf", () -> new EjgfFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_EJGF = REGISTRY.register("flowing_ejgf", () -> new EjgfFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(EJGF.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_EJGF.get(), RenderType.translucent());
		}
	}
}
