
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.evanwarthen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.evanwarthen.fluid.types.EjgfFluidType;
import net.mcreator.evanwarthen.EvanwarthenMod;

public class EvanwarthenModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, EvanwarthenMod.MODID);
	public static final RegistryObject<FluidType> EJGF_TYPE = REGISTRY.register("ejgf", () -> new EjgfFluidType());
}
