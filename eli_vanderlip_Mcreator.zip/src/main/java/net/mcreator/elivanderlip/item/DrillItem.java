
package net.mcreator.elivanderlip.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.FishingRodItem;

public class DrillItem extends FishingRodItem {
	public DrillItem() {
		super(new Item.Properties().durability(100));
	}

	@Override
	public int getEnchantmentValue() {
		return 2;
	}
}
