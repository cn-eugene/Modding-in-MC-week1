
package net.mcreator.elivanderlip.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.damagesource.DamageSource;

public class AmogusEnchantment extends Enchantment {
	public AmogusEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.WEAPON, slots);
	}

	@Override
	public int getMinLevel() {
		return 26;
	}

	@Override
	public int getMaxLevel() {
		return 26;
	}

	@Override
	public int getDamageProtection(int level, DamageSource source) {
		return level * 36;
	}

	@Override
	public boolean isCurse() {
		return true;
	}
}
