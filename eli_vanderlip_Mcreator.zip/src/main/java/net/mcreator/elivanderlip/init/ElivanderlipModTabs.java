
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.elivanderlip.ElivanderlipMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ElivanderlipModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ElivanderlipMod.MODID);
	public static final RegistryObject<CreativeModeTab> XY_2332 = REGISTRY.register("xy_2332",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.elivanderlip.xy_2332")).icon(() -> new ItemStack(Blocks.PLAYER_WALL_HEAD)).displayItems((parameters, tabData) -> {
				tabData.accept(ElivanderlipModItems.REINFORCEDPRISMERIEN.get());
				tabData.accept(ElivanderlipModItems.GUN.get());
				tabData.accept(ElivanderlipModBlocks.BEARTRAP.get().asItem());
				tabData.accept(ElivanderlipModItems.SWORD.get());
				tabData.accept(ElivanderlipModBlocks.RAINBOW.get().asItem());
				tabData.accept(ElivanderlipModItems.RAINBOWINGOT.get());
				tabData.accept(ElivanderlipModItems.SLICER.get());
				tabData.accept(ElivanderlipModItems.BAZOOKA.get());
				tabData.accept(ElivanderlipModItems.NINJA_SPAWN_EGG.get());
				tabData.accept(ElivanderlipModItems.DRILL.get());
				tabData.accept(ElivanderlipModBlocks.TNTPLANT.get().asItem());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ElivanderlipModItems.NETHERITE.get());
			tabData.accept(ElivanderlipModItems.SKY.get());
		}
	}
}
