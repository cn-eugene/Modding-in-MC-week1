
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.elivanderlip.enchantment.AmogusEnchantment;
import net.mcreator.elivanderlip.ElivanderlipMod;

public class ElivanderlipModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, ElivanderlipMod.MODID);
	public static final RegistryObject<Enchantment> AMOGUS = REGISTRY.register("amogus", () -> new AmogusEnchantment());
}
