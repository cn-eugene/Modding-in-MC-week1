
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.elivanderlip.item.SlicerItem;
import net.mcreator.elivanderlip.item.SkyItem;
import net.mcreator.elivanderlip.item.SWORDItem;
import net.mcreator.elivanderlip.item.ReinforcedprismerienItem;
import net.mcreator.elivanderlip.item.RAINBOWINGOTItem;
import net.mcreator.elivanderlip.item.NetheriteItem;
import net.mcreator.elivanderlip.item.GunItem;
import net.mcreator.elivanderlip.item.DrillItem;
import net.mcreator.elivanderlip.item.BazookaItem;
import net.mcreator.elivanderlip.ElivanderlipMod;

public class ElivanderlipModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ElivanderlipMod.MODID);
	public static final RegistryObject<Item> REINFORCEDPRISMERIEN = REGISTRY.register("reinforcedprismerien", () -> new ReinforcedprismerienItem());
	public static final RegistryObject<Item> NETHERITE = REGISTRY.register("netherite", () -> new NetheriteItem());
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());
	public static final RegistryObject<Item> BEARTRAP = block(ElivanderlipModBlocks.BEARTRAP);
	public static final RegistryObject<Item> SWORD = REGISTRY.register("sword", () -> new SWORDItem());
	public static final RegistryObject<Item> RAINBOW = block(ElivanderlipModBlocks.RAINBOW);
	public static final RegistryObject<Item> RAINBOWINGOT = REGISTRY.register("rainbowingot", () -> new RAINBOWINGOTItem());
	public static final RegistryObject<Item> SLICER = REGISTRY.register("slicer", () -> new SlicerItem());
	public static final RegistryObject<Item> BAZOOKA = REGISTRY.register("bazooka", () -> new BazookaItem());
	public static final RegistryObject<Item> NINJA_SPAWN_EGG = REGISTRY.register("ninja_spawn_egg", () -> new ForgeSpawnEggItem(ElivanderlipModEntities.NINJA, -16777216, -10066330, new Item.Properties()));
	public static final RegistryObject<Item> DRILL = REGISTRY.register("drill", () -> new DrillItem());
	public static final RegistryObject<Item> TNTPLANT = block(ElivanderlipModBlocks.TNTPLANT);
	public static final RegistryObject<Item> SKY = REGISTRY.register("sky", () -> new SkyItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
