
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.elivanderlip.block.TntplantBlock;
import net.mcreator.elivanderlip.block.SkyPortalBlock;
import net.mcreator.elivanderlip.block.RAINBOWBlock;
import net.mcreator.elivanderlip.block.NetheritePortalBlock;
import net.mcreator.elivanderlip.block.BEARTRAPBlock;
import net.mcreator.elivanderlip.ElivanderlipMod;

public class ElivanderlipModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ElivanderlipMod.MODID);
	public static final RegistryObject<Block> NETHERITE_PORTAL = REGISTRY.register("netherite_portal", () -> new NetheritePortalBlock());
	public static final RegistryObject<Block> BEARTRAP = REGISTRY.register("beartrap", () -> new BEARTRAPBlock());
	public static final RegistryObject<Block> RAINBOW = REGISTRY.register("rainbow", () -> new RAINBOWBlock());
	public static final RegistryObject<Block> TNTPLANT = REGISTRY.register("tntplant", () -> new TntplantBlock());
	public static final RegistryObject<Block> SKY_PORTAL = REGISTRY.register("sky_portal", () -> new SkyPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
