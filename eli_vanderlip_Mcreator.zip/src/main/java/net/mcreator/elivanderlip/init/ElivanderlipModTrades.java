
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.elivanderlip.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ElivanderlipModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == ElivanderlipModVillagerProfessions.EXPLORER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(ElivanderlipModBlocks.TNTPLANT.get()),

					new ItemStack(ElivanderlipModItems.DRILL.get()), 10, 5, 0.05f));
		}
		if (event.getType() == ElivanderlipModVillagerProfessions.EXPLORER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(ElivanderlipModItems.RAINBOWINGOT.get()),

					new ItemStack(ElivanderlipModItems.SKY.get()), 10, 5, 0.05f));
		}
		if (event.getType() == ElivanderlipModVillagerProfessions.EXPLORER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Blocks.RAW_GOLD_BLOCK),

					new ItemStack(ElivanderlipModBlocks.BEARTRAP.get()), 10, 5, 0.05f));
		}
		if (event.getType() == ElivanderlipModVillagerProfessions.EXPLORER.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.HOST_ARMOR_TRIM_SMITHING_TEMPLATE),

					new ItemStack(ElivanderlipModItems.BAZOOKA.get()), 10, 5, 0.05f));
		}
	}
}
