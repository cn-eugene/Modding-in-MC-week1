
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.elivanderlip.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.elivanderlip.entity.TntEntity;
import net.mcreator.elivanderlip.entity.NinjaEntity;
import net.mcreator.elivanderlip.entity.FireEntity;
import net.mcreator.elivanderlip.entity.BULLETEntity;
import net.mcreator.elivanderlip.ElivanderlipMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ElivanderlipModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ElivanderlipMod.MODID);
	public static final RegistryObject<EntityType<BULLETEntity>> BULLET = register("bullet",
			EntityType.Builder.<BULLETEntity>of(BULLETEntity::new, MobCategory.MISC).setCustomClientFactory(BULLETEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<FireEntity>> FIRE = register("fire",
			EntityType.Builder.<FireEntity>of(FireEntity::new, MobCategory.MISC).setCustomClientFactory(FireEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TntEntity>> TNT = register("tnt",
			EntityType.Builder.<TntEntity>of(TntEntity::new, MobCategory.MISC).setCustomClientFactory(TntEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<NinjaEntity>> NINJA = register("ninja",
			EntityType.Builder.<NinjaEntity>of(NinjaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(NinjaEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			NinjaEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(NINJA.get(), NinjaEntity.createAttributes().build());
	}
}
