
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.axelmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.axelmod.item.YesItem;
import net.mcreator.axelmod.item.WeiyItem;
import net.mcreator.axelmod.item.WeirdworldItem;
import net.mcreator.axelmod.item.ThonderItem;
import net.mcreator.axelmod.item.OnhItem;
import net.mcreator.axelmod.item.Fghj54Item;
import net.mcreator.axelmod.item.DudeeItem;
import net.mcreator.axelmod.item.Dude2Item;
import net.mcreator.axelmod.item.DieItem;
import net.mcreator.axelmod.item.Asd2Item;
import net.mcreator.axelmod.AxelModMod;

public class AxelModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AxelModMod.MODID);
	public static final RegistryObject<Item> ASDGJLHR = block(AxelModModBlocks.ASDGJLHR);
	public static final RegistryObject<Item> DUDE_2 = REGISTRY.register("dude_2", () -> new Dude2Item());
	public static final RegistryObject<Item> DUDEE = REGISTRY.register("dudee", () -> new DudeeItem());
	public static final RegistryObject<Item> YEAH_2 = block(AxelModModBlocks.YEAH_2);
	public static final RegistryObject<Item> YES = REGISTRY.register("yes", () -> new YesItem());
	public static final RegistryObject<Item> ONH = REGISTRY.register("onh", () -> new OnhItem());
	public static final RegistryObject<Item> DIE = REGISTRY.register("die", () -> new DieItem());
	public static final RegistryObject<Item> WEIRDWORLD = REGISTRY.register("weirdworld", () -> new WeirdworldItem());
	public static final RegistryObject<Item> WEIY = REGISTRY.register("weiy", () -> new WeiyItem());
	public static final RegistryObject<Item> FGHJ_54_HELMET = REGISTRY.register("fghj_54_helmet", () -> new Fghj54Item.Helmet());
	public static final RegistryObject<Item> FGHJ_54_CHESTPLATE = REGISTRY.register("fghj_54_chestplate", () -> new Fghj54Item.Chestplate());
	public static final RegistryObject<Item> FGHJ_54_LEGGINGS = REGISTRY.register("fghj_54_leggings", () -> new Fghj54Item.Leggings());
	public static final RegistryObject<Item> FGHJ_54_BOOTS = REGISTRY.register("fghj_54_boots", () -> new Fghj54Item.Boots());
	public static final RegistryObject<Item> THONDER = REGISTRY.register("thonder", () -> new ThonderItem());
	public static final RegistryObject<Item> ASD_2 = REGISTRY.register("asd_2", () -> new Asd2Item());
	public static final RegistryObject<Item> DEATH_SPAWN_EGG = REGISTRY.register("death_spawn_egg", () -> new ForgeSpawnEggItem(AxelModModEntities.DEATH, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> RUN_SPAWN_EGG = REGISTRY.register("run_spawn_egg", () -> new ForgeSpawnEggItem(AxelModModEntities.RUN, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
