
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.axelmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.axelmod.client.renderer.RUNRenderer;
import net.mcreator.axelmod.client.renderer.DEATHRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AxelModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(AxelModModEntities.FGH_3.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AxelModModEntities.DEATH.get(), DEATHRenderer::new);
		event.registerEntityRenderer(AxelModModEntities.RUN.get(), RUNRenderer::new);
	}
}
