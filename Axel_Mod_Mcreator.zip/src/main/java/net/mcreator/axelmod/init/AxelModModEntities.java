
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.axelmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.axelmod.entity.RUNEntity;
import net.mcreator.axelmod.entity.Fgh3Entity;
import net.mcreator.axelmod.entity.DEATHEntity;
import net.mcreator.axelmod.AxelModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AxelModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AxelModMod.MODID);
	public static final RegistryObject<EntityType<Fgh3Entity>> FGH_3 = register("fgh_3",
			EntityType.Builder.<Fgh3Entity>of(Fgh3Entity::new, MobCategory.MISC).setCustomClientFactory(Fgh3Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<DEATHEntity>> DEATH = register("death",
			EntityType.Builder.<DEATHEntity>of(DEATHEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DEATHEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<RUNEntity>> RUN = register("run",
			EntityType.Builder.<RUNEntity>of(RUNEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(RUNEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DEATHEntity.init();
			RUNEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DEATH.get(), DEATHEntity.createAttributes().build());
		event.put(RUN.get(), RUNEntity.createAttributes().build());
	}
}
