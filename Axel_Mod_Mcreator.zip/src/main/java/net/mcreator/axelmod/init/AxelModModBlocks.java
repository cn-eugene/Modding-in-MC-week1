
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.axelmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.axelmod.block.Yeah2Block;
import net.mcreator.axelmod.block.WeiyPortalBlock;
import net.mcreator.axelmod.block.WeirdworldPortalBlock;
import net.mcreator.axelmod.block.ASDGJLHRBlock;
import net.mcreator.axelmod.AxelModMod;

public class AxelModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AxelModMod.MODID);
	public static final RegistryObject<Block> ASDGJLHR = REGISTRY.register("asdgjlhr", () -> new ASDGJLHRBlock());
	public static final RegistryObject<Block> YEAH_2 = REGISTRY.register("yeah_2", () -> new Yeah2Block());
	public static final RegistryObject<Block> WEIRDWORLD_PORTAL = REGISTRY.register("weirdworld_portal", () -> new WeirdworldPortalBlock());
	public static final RegistryObject<Block> WEIY_PORTAL = REGISTRY.register("weiy_portal", () -> new WeiyPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
