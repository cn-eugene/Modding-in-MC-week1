
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.carterkoza.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.carterkoza.block.BedrockoreBlock;
import net.mcreator.carterkoza.CarterkozaMod;

public class CarterkozaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, CarterkozaMod.MODID);
	public static final RegistryObject<Block> BEDROCKORE = REGISTRY.register("bedrockore", () -> new BedrockoreBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
