
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.carterkoza.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.carterkoza.item.LavaswordItem;
import net.mcreator.carterkoza.item.LavaArmorItem;
import net.mcreator.carterkoza.item.GunItem;
import net.mcreator.carterkoza.item.FierItem;
import net.mcreator.carterkoza.item.BlockyItem;
import net.mcreator.carterkoza.CarterkozaMod;

public class CarterkozaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, CarterkozaMod.MODID);
	public static final RegistryObject<Item> FIER = REGISTRY.register("fier", () -> new FierItem());
	public static final RegistryObject<Item> BEDROCKORE = block(CarterkozaModBlocks.BEDROCKORE);
	public static final RegistryObject<Item> BLOCKY = REGISTRY.register("blocky", () -> new BlockyItem());
	public static final RegistryObject<Item> LAVASWORD = REGISTRY.register("lavasword", () -> new LavaswordItem());
	public static final RegistryObject<Item> LAVA_ARMOR_HELMET = REGISTRY.register("lava_armor_helmet", () -> new LavaArmorItem.Helmet());
	public static final RegistryObject<Item> LAVA_ARMOR_CHESTPLATE = REGISTRY.register("lava_armor_chestplate", () -> new LavaArmorItem.Chestplate());
	public static final RegistryObject<Item> LAVA_ARMOR_LEGGINGS = REGISTRY.register("lava_armor_leggings", () -> new LavaArmorItem.Leggings());
	public static final RegistryObject<Item> LAVA_ARMOR_BOOTS = REGISTRY.register("lava_armor_boots", () -> new LavaArmorItem.Boots());
	public static final RegistryObject<Item> LIM_SPAWN_EGG = REGISTRY.register("lim_spawn_egg", () -> new ForgeSpawnEggItem(CarterkozaModEntities.LIM, -10027162, -52429, new Item.Properties()));
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
