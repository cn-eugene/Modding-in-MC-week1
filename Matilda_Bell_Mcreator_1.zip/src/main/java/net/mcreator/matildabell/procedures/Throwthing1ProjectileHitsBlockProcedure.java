package net.mcreator.matildabell.procedures;

public class Throwthing1ProjectileHitsBlockProcedure {
	public static void execute() {
	}
}
