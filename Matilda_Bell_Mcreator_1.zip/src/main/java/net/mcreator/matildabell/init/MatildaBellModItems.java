
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabell.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.matildabell.item.ThrowthingItem;
import net.mcreator.matildabell.item.SheildcatItem;
import net.mcreator.matildabell.item.ShearcItem;
import net.mcreator.matildabell.item.ChoeItem;
import net.mcreator.matildabell.item.CaxeItem;
import net.mcreator.matildabell.item.CatrodofcatsItem;
import net.mcreator.matildabell.item.CaticospearItem;
import net.mcreator.matildabell.item.CaticoshovelItem;
import net.mcreator.matildabell.item.CaticopicaxeItem;
import net.mcreator.matildabell.item.CaticoGemItem;
import net.mcreator.matildabell.item.CatarmorItem;
import net.mcreator.matildabell.item.BroccoliItem;
import net.mcreator.matildabell.item.BaguetteItem;
import net.mcreator.matildabell.MatildaBellMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MatildaBellModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MatildaBellMod.MODID);
	public static final RegistryObject<Item> BATHROOM_TILE = block(MatildaBellModBlocks.BATHROOM_TILE);
	public static final RegistryObject<Item> KITCHEN_TILE = block(MatildaBellModBlocks.KITCHEN_TILE);
	public static final RegistryObject<Item> CAT_ORE = block(MatildaBellModBlocks.CAT_ORE);
	public static final RegistryObject<Item> CATICO_GEM = REGISTRY.register("catico_gem", () -> new CaticoGemItem());
	public static final RegistryObject<Item> CATICOPICAXE = REGISTRY.register("caticopicaxe", () -> new CaticopicaxeItem());
	public static final RegistryObject<Item> CATICOSPEAR = REGISTRY.register("caticospear", () -> new CaticospearItem());
	public static final RegistryObject<Item> CATICOSHOVEL = REGISTRY.register("caticoshovel", () -> new CaticoshovelItem());
	public static final RegistryObject<Item> CHOE = REGISTRY.register("choe", () -> new ChoeItem());
	public static final RegistryObject<Item> CAXE = REGISTRY.register("caxe", () -> new CaxeItem());
	public static final RegistryObject<Item> SHEARC = REGISTRY.register("shearc", () -> new ShearcItem());
	public static final RegistryObject<Item> SHEILDCAT = REGISTRY.register("sheildcat", () -> new SheildcatItem());
	public static final RegistryObject<Item> CATRODOFCATS = REGISTRY.register("catrodofcats", () -> new CatrodofcatsItem());
	public static final RegistryObject<Item> CATARMOR_HELMET = REGISTRY.register("catarmor_helmet", () -> new CatarmorItem.Helmet());
	public static final RegistryObject<Item> CATARMOR_CHESTPLATE = REGISTRY.register("catarmor_chestplate", () -> new CatarmorItem.Chestplate());
	public static final RegistryObject<Item> CATARMOR_LEGGINGS = REGISTRY.register("catarmor_leggings", () -> new CatarmorItem.Leggings());
	public static final RegistryObject<Item> CATARMOR_BOOTS = REGISTRY.register("catarmor_boots", () -> new CatarmorItem.Boots());
	public static final RegistryObject<Item> THROWTHING = REGISTRY.register("throwthing", () -> new ThrowthingItem());
	public static final RegistryObject<Item> KATHY_SPAWN_EGG = REGISTRY.register("kathy_spawn_egg", () -> new ForgeSpawnEggItem(MatildaBellModEntities.KATHY, -10092544, -472678, new Item.Properties()));
	public static final RegistryObject<Item> BROCCOLI = REGISTRY.register("broccoli", () -> new BroccoliItem());
	public static final RegistryObject<Item> BAGUETTE = REGISTRY.register("baguette", () -> new BaguetteItem());
	public static final RegistryObject<Item> BROCCOLIPLANT = block(MatildaBellModBlocks.BROCCOLIPLANT);
	public static final RegistryObject<Item> BROCCOLIBABY = block(MatildaBellModBlocks.BROCCOLIBABY);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			ItemProperties.register(SHEILDCAT.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
		});
	}
}
