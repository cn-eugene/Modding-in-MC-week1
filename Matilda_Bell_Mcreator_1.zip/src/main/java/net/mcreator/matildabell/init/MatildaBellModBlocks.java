
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabell.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.matildabell.block.KitchenTileBlock;
import net.mcreator.matildabell.block.CatOreBlock;
import net.mcreator.matildabell.block.BroccoliplantBlock;
import net.mcreator.matildabell.block.BroccolibabyBlock;
import net.mcreator.matildabell.block.BathroomTileBlock;
import net.mcreator.matildabell.MatildaBellMod;

public class MatildaBellModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MatildaBellMod.MODID);
	public static final RegistryObject<Block> BATHROOM_TILE = REGISTRY.register("bathroom_tile", () -> new BathroomTileBlock());
	public static final RegistryObject<Block> KITCHEN_TILE = REGISTRY.register("kitchen_tile", () -> new KitchenTileBlock());
	public static final RegistryObject<Block> CAT_ORE = REGISTRY.register("cat_ore", () -> new CatOreBlock());
	public static final RegistryObject<Block> BROCCOLIPLANT = REGISTRY.register("broccoliplant", () -> new BroccoliplantBlock());
	public static final RegistryObject<Block> BROCCOLIBABY = REGISTRY.register("broccolibaby", () -> new BroccolibabyBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
