
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabell.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.matildabell.MatildaBellMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MatildaBellModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MatildaBellMod.MODID);
	public static final RegistryObject<CreativeModeTab> CATSTUFF = REGISTRY.register("catstuff",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.matilda_bell.catstuff")).icon(() -> new ItemStack(MatildaBellModItems.CATICO_GEM.get())).displayItems((parameters, tabData) -> {
				tabData.accept(MatildaBellModBlocks.KITCHEN_TILE.get().asItem());
				tabData.accept(MatildaBellModBlocks.BATHROOM_TILE.get().asItem());
				tabData.accept(MatildaBellModBlocks.CAT_ORE.get().asItem());
				tabData.accept(MatildaBellModItems.CATICO_GEM.get());
				tabData.accept(MatildaBellModItems.CATICOPICAXE.get());
				tabData.accept(MatildaBellModItems.CATICOSPEAR.get());
				tabData.accept(MatildaBellModItems.CATICOSHOVEL.get());
				tabData.accept(MatildaBellModItems.CHOE.get());
				tabData.accept(MatildaBellModItems.CAXE.get());
				tabData.accept(MatildaBellModItems.SHEARC.get());
				tabData.accept(MatildaBellModItems.SHEILDCAT.get());
				tabData.accept(MatildaBellModItems.CATRODOFCATS.get());
				tabData.accept(MatildaBellModItems.CATARMOR_HELMET.get());
				tabData.accept(MatildaBellModItems.CATARMOR_CHESTPLATE.get());
				tabData.accept(MatildaBellModItems.CATARMOR_LEGGINGS.get());
				tabData.accept(MatildaBellModItems.CATARMOR_BOOTS.get());
				tabData.accept(MatildaBellModItems.THROWTHING.get());
				tabData.accept(MatildaBellModItems.KATHY_SPAWN_EGG.get());
				tabData.accept(MatildaBellModItems.BAGUETTE.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(MatildaBellModItems.BROCCOLI.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MatildaBellModBlocks.BROCCOLIPLANT.get().asItem());
			tabData.accept(MatildaBellModBlocks.BROCCOLIBABY.get().asItem());
		}
	}
}
