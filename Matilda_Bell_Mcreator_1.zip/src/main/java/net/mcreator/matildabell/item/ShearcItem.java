
package net.mcreator.matildabell.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ShearsItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class ShearcItem extends ShearsItem {
	public ShearcItem() {
		super(new Item.Properties().durability(300));
	}

	@Override
	public int getEnchantmentValue() {
		return 3;
	}

	@Override
	public float getDestroySpeed(ItemStack stack, BlockState blockstate) {
		return 30f;
	}
}
