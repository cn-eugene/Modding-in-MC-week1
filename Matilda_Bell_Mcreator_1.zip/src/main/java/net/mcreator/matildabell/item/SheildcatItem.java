
package net.mcreator.matildabell.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class SheildcatItem extends ShieldItem {
	public SheildcatItem() {
		super(new Item.Properties().durability(250));
	}
}
