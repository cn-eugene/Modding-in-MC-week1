
package net.mcreator.matildabell.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.FishingRodItem;

public class CatrodofcatsItem extends FishingRodItem {
	public CatrodofcatsItem() {
		super(new Item.Properties().durability(300));
	}

	@Override
	public int getEnchantmentValue() {
		return 15;
	}
}
