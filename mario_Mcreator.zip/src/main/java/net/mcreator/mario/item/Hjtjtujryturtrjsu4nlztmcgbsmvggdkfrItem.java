
package net.mcreator.mario.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.mario.init.MarioModFluids;

public class Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrItem extends BucketItem {
	public Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrItem() {
		super(MarioModFluids.HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
