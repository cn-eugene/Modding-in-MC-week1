
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mario.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.mario.MarioMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MarioModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MarioMod.MODID);
	public static final RegistryObject<CreativeModeTab> JDJTIEWHTG = REGISTRY.register("jdjtiewhtg",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.mario.jdjtiewhtg")).icon(() -> new ItemStack(MarioModItems.EYESTAFF.get())).displayItems((parameters, tabData) -> {
				tabData.accept(MarioModItems.EYE_ORE_INGOT.get());
				tabData.accept(MarioModItems.HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR_BUCKET.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(MarioModBlocks.EYE_ORE_ORE.get().asItem());
			tabData.accept(MarioModBlocks.EYE_ORE_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MarioModItems.EYESWORD.get());
			tabData.accept(MarioModItems.EYE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MarioModItems.EYEMOSTER_SPAWN_EGG.get());
		}
	}
}
