
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mario.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.mario.block.Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrBlock;
import net.mcreator.mario.block.Eye_oreOreBlock;
import net.mcreator.mario.block.Eye_oreBlockBlock;
import net.mcreator.mario.MarioMod;

public class MarioModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MarioMod.MODID);
	public static final RegistryObject<Block> EYE_ORE_ORE = REGISTRY.register("eye_ore_ore", () -> new Eye_oreOreBlock());
	public static final RegistryObject<Block> EYE_ORE_BLOCK = REGISTRY.register("eye_ore_block", () -> new Eye_oreBlockBlock());
	public static final RegistryObject<Block> HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR = REGISTRY.register("hjtjtujryturtrjsu_4nlztmcgbsmvggdkfr", () -> new Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
