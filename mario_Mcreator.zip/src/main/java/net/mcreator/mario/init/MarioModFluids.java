
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mario.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.mario.fluid.Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluid;
import net.mcreator.mario.MarioMod;

public class MarioModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, MarioMod.MODID);
	public static final RegistryObject<FlowingFluid> HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR = REGISTRY.register("hjtjtujryturtrjsu_4nlztmcgbsmvggdkfr", () -> new Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR = REGISTRY.register("flowing_hjtjtujryturtrjsu_4nlztmcgbsmvggdkfr", () -> new Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR.get(), RenderType.translucent());
		}
	}
}
