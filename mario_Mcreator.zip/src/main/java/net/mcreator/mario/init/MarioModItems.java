
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mario.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mario.item.Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrItem;
import net.mcreator.mario.item.EyeswordItem;
import net.mcreator.mario.item.EyestaffItem;
import net.mcreator.mario.item.Eye_oreIngotItem;
import net.mcreator.mario.item.EyeItem;
import net.mcreator.mario.MarioMod;

public class MarioModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MarioMod.MODID);
	public static final RegistryObject<Item> EYE_ORE_INGOT = REGISTRY.register("eye_ore_ingot", () -> new Eye_oreIngotItem());
	public static final RegistryObject<Item> EYE_ORE_ORE = block(MarioModBlocks.EYE_ORE_ORE);
	public static final RegistryObject<Item> EYE_ORE_BLOCK = block(MarioModBlocks.EYE_ORE_BLOCK);
	public static final RegistryObject<Item> EYESWORD = REGISTRY.register("eyesword", () -> new EyeswordItem());
	public static final RegistryObject<Item> EYE = REGISTRY.register("eye", () -> new EyeItem());
	public static final RegistryObject<Item> EYESTAFF = REGISTRY.register("eyestaff", () -> new EyestaffItem());
	public static final RegistryObject<Item> EYEMOSTER_SPAWN_EGG = REGISTRY.register("eyemoster_spawn_egg", () -> new ForgeSpawnEggItem(MarioModEntities.EYEMOSTER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR_BUCKET = REGISTRY.register("hjtjtujryturtrjsu_4nlztmcgbsmvggdkfr_bucket", () -> new Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
