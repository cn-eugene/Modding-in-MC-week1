
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mario.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.mario.fluid.types.Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluidType;
import net.mcreator.mario.MarioMod;

public class MarioModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, MarioMod.MODID);
	public static final RegistryObject<FluidType> HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR_TYPE = REGISTRY.register("hjtjtujryturtrjsu_4nlztmcgbsmvggdkfr", () -> new Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluidType());
}
