
package net.mcreator.mario.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.mario.init.MarioModItems;
import net.mcreator.mario.init.MarioModFluids;
import net.mcreator.mario.init.MarioModFluidTypes;
import net.mcreator.mario.init.MarioModBlocks;

public abstract class Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> MarioModFluidTypes.HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR_TYPE.get(), () -> MarioModFluids.HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR.get(),
			() -> MarioModFluids.FLOWING_HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR.get()).explosionResistance(100f).tickRate(173).slopeFindDistance(16).bucket(() -> MarioModItems.HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR_BUCKET.get())
			.block(() -> (LiquidBlock) MarioModBlocks.HJTJTUJRYTURTRJSU_4NLZTMCGBSMVGGDKFR.get());

	private Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.WITCH;
	}

	public static class Source extends Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends Hjtjtujryturtrjsu4nlztmcgbsmvggdkfrFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
