
package net.mcreator.senseichazmasters.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

import com.mojang.serialization.MapCodec;

public class StarSandBlock extends FallingBlock {
	public static final MapCodec<StarSandBlock> CODEC = simpleCodec(StarSandBlock::new);

	public MapCodec<StarSandBlock> codec() {
		return CODEC;
	}

	public StarSandBlock(BlockBehaviour.Properties ignored) {
		this();
	}

	public StarSandBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.SNARE).sound(SoundType.SAND).strength(1f, 10f));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}
