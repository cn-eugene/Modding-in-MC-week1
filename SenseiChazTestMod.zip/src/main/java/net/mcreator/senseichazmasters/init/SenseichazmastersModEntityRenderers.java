
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.senseichazmasters.client.renderer.StarChickenRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SenseichazmastersModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(SenseichazmastersModEntities.STAR_CHICKEN.get(), StarChickenRenderer::new);
		event.registerEntityRenderer(SenseichazmastersModEntities.DR_RANGED_P.get(), ThrownItemRenderer::new);
	}
}
