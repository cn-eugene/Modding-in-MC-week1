
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.senseichazmasters.SenseichazmastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SenseichazmastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SenseichazmastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(SenseichazmastersModBlocks.NINJA_TNT.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.DR_SUPER_TNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(SenseichazmastersModItems.NINJA_WEAPON.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_HELMET.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_CHESTPLATE.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_LEGGINGS.get());
			tabData.accept(SenseichazmastersModItems.NINJA_ARMOR_BOOTS.get());
			tabData.accept(SenseichazmastersModItems.DR_NINJA_SWORD.get());
			tabData.accept(SenseichazmastersModItems.DR_RANGED_1.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(SenseichazmastersModItems.STAR_CHICKEN_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(SenseichazmastersModItems.NINJA_ORE.get());
			tabData.accept(SenseichazmastersModItems.NINJA_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(SenseichazmastersModBlocks.NINJA_ORE_BLOCK.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_DIRT.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_GRASS.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_LOG.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_SAND.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_LEAF.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.STAR_FLOWER.get().asItem());
			tabData.accept(SenseichazmastersModBlocks.DR_NINJA_ORE_BLOCK.get().asItem());
		}
	}
}
