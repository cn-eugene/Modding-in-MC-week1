
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.bus.api.IEventBus;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.senseichazmasters.item.NinjaWeaponItem;
import net.mcreator.senseichazmasters.item.NinjaOreItem;
import net.mcreator.senseichazmasters.item.NinjaIngotItem;
import net.mcreator.senseichazmasters.item.NinjaArmorItem;
import net.mcreator.senseichazmasters.item.DRRanged1Item;
import net.mcreator.senseichazmasters.item.DRNinjaSwordItem;
import net.mcreator.senseichazmasters.item.DRNinjaOreItem;
import net.mcreator.senseichazmasters.item.DRNinjaIngotItem;
import net.mcreator.senseichazmasters.SenseichazmastersMod;

public class SenseichazmastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, SenseichazmastersMod.MODID);
	public static final DeferredHolder<Item, Item> NINJA_ORE = REGISTRY.register("ninja_ore", () -> new NinjaOreItem());
	public static final DeferredHolder<Item, Item> NINJA_ORE_BLOCK = block(SenseichazmastersModBlocks.NINJA_ORE_BLOCK);
	public static final DeferredHolder<Item, Item> NINJA_INGOT = REGISTRY.register("ninja_ingot", () -> new NinjaIngotItem());
	public static final DeferredHolder<Item, Item> NINJA_WEAPON = REGISTRY.register("ninja_weapon", () -> new NinjaWeaponItem());
	public static final DeferredHolder<Item, Item> NINJA_TNT = block(SenseichazmastersModBlocks.NINJA_TNT);
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_HELMET = REGISTRY.register("ninja_armor_helmet", () -> new NinjaArmorItem.Helmet());
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_CHESTPLATE = REGISTRY.register("ninja_armor_chestplate", () -> new NinjaArmorItem.Chestplate());
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_LEGGINGS = REGISTRY.register("ninja_armor_leggings", () -> new NinjaArmorItem.Leggings());
	public static final DeferredHolder<Item, Item> NINJA_ARMOR_BOOTS = REGISTRY.register("ninja_armor_boots", () -> new NinjaArmorItem.Boots());
	public static final DeferredHolder<Item, Item> STAR_DIRT = block(SenseichazmastersModBlocks.STAR_DIRT);
	public static final DeferredHolder<Item, Item> STAR_GRASS = block(SenseichazmastersModBlocks.STAR_GRASS);
	public static final DeferredHolder<Item, Item> STAR_LOG = block(SenseichazmastersModBlocks.STAR_LOG);
	public static final DeferredHolder<Item, Item> STAR_SAND = block(SenseichazmastersModBlocks.STAR_SAND);
	public static final DeferredHolder<Item, Item> STAR_LEAF = block(SenseichazmastersModBlocks.STAR_LEAF);
	public static final DeferredHolder<Item, Item> STAR_FLOWER = block(SenseichazmastersModBlocks.STAR_FLOWER);
	public static final DeferredHolder<Item, Item> STAR_CHICKEN_SPAWN_EGG = REGISTRY.register("star_chicken_spawn_egg", () -> new DeferredSpawnEggItem(SenseichazmastersModEntities.STAR_CHICKEN, -103, -52276, new Item.Properties()));
	public static final DeferredHolder<Item, Item> DR_NINJA_ORE = REGISTRY.register("dr_ninja_ore", () -> new DRNinjaOreItem());
	public static final DeferredHolder<Item, Item> DR_NINJA_ORE_BLOCK = block(SenseichazmastersModBlocks.DR_NINJA_ORE_BLOCK);
	public static final DeferredHolder<Item, Item> DR_NINJA_INGOT = REGISTRY.register("dr_ninja_ingot", () -> new DRNinjaIngotItem());
	public static final DeferredHolder<Item, Item> DR_NINJA_SWORD = REGISTRY.register("dr_ninja_sword", () -> new DRNinjaSwordItem());
	public static final DeferredHolder<Item, Item> DR_RANGED_1 = REGISTRY.register("dr_ranged_1", () -> new DRRanged1Item());
	public static final DeferredHolder<Item, Item> DR_SUPER_TNT = block(SenseichazmastersModBlocks.DR_SUPER_TNT);

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
