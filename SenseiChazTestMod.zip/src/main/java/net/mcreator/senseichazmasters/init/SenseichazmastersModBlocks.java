
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.senseichazmasters.block.StarSandBlock;
import net.mcreator.senseichazmasters.block.StarLogBlock;
import net.mcreator.senseichazmasters.block.StarLeafBlock;
import net.mcreator.senseichazmasters.block.StarGrassBlock;
import net.mcreator.senseichazmasters.block.StarFlowerBlock;
import net.mcreator.senseichazmasters.block.StarDirtBlock;
import net.mcreator.senseichazmasters.block.NinjaTNTBlock;
import net.mcreator.senseichazmasters.block.NinjaOreBlockBlock;
import net.mcreator.senseichazmasters.block.DrSuperTNTBlock;
import net.mcreator.senseichazmasters.block.DrNinjaOreBlockBlock;
import net.mcreator.senseichazmasters.SenseichazmastersMod;

public class SenseichazmastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, SenseichazmastersMod.MODID);
	public static final DeferredHolder<Block, Block> NINJA_ORE_BLOCK = REGISTRY.register("ninja_ore_block", () -> new NinjaOreBlockBlock());
	public static final DeferredHolder<Block, Block> NINJA_TNT = REGISTRY.register("ninja_tnt", () -> new NinjaTNTBlock());
	public static final DeferredHolder<Block, Block> STAR_DIRT = REGISTRY.register("star_dirt", () -> new StarDirtBlock());
	public static final DeferredHolder<Block, Block> STAR_GRASS = REGISTRY.register("star_grass", () -> new StarGrassBlock());
	public static final DeferredHolder<Block, Block> STAR_LOG = REGISTRY.register("star_log", () -> new StarLogBlock());
	public static final DeferredHolder<Block, Block> STAR_SAND = REGISTRY.register("star_sand", () -> new StarSandBlock());
	public static final DeferredHolder<Block, Block> STAR_LEAF = REGISTRY.register("star_leaf", () -> new StarLeafBlock());
	public static final DeferredHolder<Block, Block> STAR_FLOWER = REGISTRY.register("star_flower", () -> new StarFlowerBlock());
	public static final DeferredHolder<Block, Block> DR_NINJA_ORE_BLOCK = REGISTRY.register("dr_ninja_ore_block", () -> new DrNinjaOreBlockBlock());
	public static final DeferredHolder<Block, Block> DR_SUPER_TNT = REGISTRY.register("dr_super_tnt", () -> new DrSuperTNTBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
