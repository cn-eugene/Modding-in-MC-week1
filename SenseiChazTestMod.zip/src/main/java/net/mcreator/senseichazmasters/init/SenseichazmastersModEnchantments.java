
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.senseichazmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.core.registries.Registries;

import net.mcreator.senseichazmasters.enchantment.Option1Enchantment;
import net.mcreator.senseichazmasters.enchantment.OPtion2Enchantment;
import net.mcreator.senseichazmasters.SenseichazmastersMod;

public class SenseichazmastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(Registries.ENCHANTMENT, SenseichazmastersMod.MODID);
	public static final DeferredHolder<Enchantment, Enchantment> OPTION_1 = REGISTRY.register("option_1", () -> new Option1Enchantment());
	public static final DeferredHolder<Enchantment, Enchantment> O_PTION_2 = REGISTRY.register("o_ption_2", () -> new OPtion2Enchantment());
}
