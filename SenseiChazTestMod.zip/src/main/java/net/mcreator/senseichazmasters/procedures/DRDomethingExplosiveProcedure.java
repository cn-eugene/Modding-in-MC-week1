package net.mcreator.senseichazmasters.procedures;

public class DRDomethingExplosiveProcedure {
	public static void execute() {
	}
}
