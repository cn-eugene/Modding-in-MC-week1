
package net.mcreator.senseichazmasters.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.InstantenousMobEffect;

import net.mcreator.senseichazmasters.procedures.ExploadingPotionEffectStartedappliedProcedure;

public class ExploadingPotionMobEffect extends InstantenousMobEffect {
	public ExploadingPotionMobEffect() {
		super(MobEffectCategory.HARMFUL, -6750208);
	}

	@Override
	public void applyInstantenousEffect(Entity source, Entity indirectSource, LivingEntity entity, int amplifier, double health) {
		ExploadingPotionEffectStartedappliedProcedure.execute(entity.level(), entity);
	}
}
