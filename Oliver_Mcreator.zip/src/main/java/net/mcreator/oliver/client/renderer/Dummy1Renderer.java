
package net.mcreator.oliver.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SlimeModel;

import net.mcreator.oliver.entity.Dummy1Entity;

public class Dummy1Renderer extends MobRenderer<Dummy1Entity, SlimeModel<Dummy1Entity>> {
	public Dummy1Renderer(EntityRendererProvider.Context context) {
		super(context, new SlimeModel(context.bakeLayer(ModelLayers.SLIME)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(Dummy1Entity entity) {
		return new ResourceLocation("oliver:textures/entities/3358e27363b35d1a9dc8dea62cc59e8c3a87299e.png");
	}
}
