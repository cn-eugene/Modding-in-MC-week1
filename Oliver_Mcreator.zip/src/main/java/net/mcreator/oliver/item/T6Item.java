
package net.mcreator.oliver.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.HoeItem;

public class T6Item extends HoeItem {
	public T6Item() {
		super(new Tier() {
			public int getUses() {
				return 100;
			}

			public float getSpeed() {
				return 42.5f;
			}

			public float getAttackDamageBonus() {
				return 4.7f;
			}

			public int getLevel() {
				return 294;
			}

			public int getEnchantmentValue() {
				return 111;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 0, 2.2f, new Item.Properties());
	}
}
