
package net.mcreator.oliver.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;

public class RedswordItem extends SwordItem {
	public RedswordItem() {
		super(new Tier() {
			public int getUses() {
				return 302;
			}

			public float getSpeed() {
				return 53.5f;
			}

			public float getAttackDamageBonus() {
				return 0f;
			}

			public int getLevel() {
				return 100;
			}

			public int getEnchantmentValue() {
				return 33;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 3, -3f, new Item.Properties());
	}
}
