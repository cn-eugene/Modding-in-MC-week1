
package net.mcreator.oliver.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

public class T8Item extends AxeItem {
	public T8Item() {
		super(new Tier() {
			public int getUses() {
				return 126;
			}

			public float getSpeed() {
				return 15.5f;
			}

			public float getAttackDamageBonus() {
				return 8.4f;
			}

			public int getLevel() {
				return 110;
			}

			public int getEnchantmentValue() {
				return 111;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 1, 8.5f, new Item.Properties());
	}
}
