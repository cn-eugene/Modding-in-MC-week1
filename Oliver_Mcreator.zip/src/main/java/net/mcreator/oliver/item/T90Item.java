
package net.mcreator.oliver.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;

public class T90Item extends SwordItem {
	public T90Item() {
		super(new Tier() {
			public int getUses() {
				return 114;
			}

			public float getSpeed() {
				return 129f;
			}

			public float getAttackDamageBonus() {
				return 4.3f;
			}

			public int getLevel() {
				return 534;
			}

			public int getEnchantmentValue() {
				return 169;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of();
			}
		}, 3, -0.3f, new Item.Properties());
	}
}
