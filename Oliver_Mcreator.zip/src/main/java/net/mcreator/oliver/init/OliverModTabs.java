
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliver.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.oliver.OliverMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OliverModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OliverMod.MODID);
	public static final RegistryObject<CreativeModeTab> T_44 = REGISTRY.register("t_44",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.oliver.t_44")).icon(() -> new ItemStack(OliverModBlocks.BLUEBERRIES.get())).displayItems((parameters, tabData) -> {
				tabData.accept(OliverModItems.REDSTUFF.get());
				tabData.accept(OliverModBlocks.REDORE.get().asItem());
				tabData.accept(OliverModItems.REDSWORD.get());
				tabData.accept(OliverModItems.TOOL.get());
				tabData.accept(OliverModItems.A_HELMET.get());
				tabData.accept(OliverModItems.A_CHESTPLATE.get());
				tabData.accept(OliverModItems.A_LEGGINGS.get());
				tabData.accept(OliverModItems.A_BOOTS.get());
				tabData.accept(OliverModItems.XITEM.get());
				tabData.accept(OliverModItems.T_4.get());
				tabData.accept(OliverModItems.T_8.get());
				tabData.accept(OliverModItems.T_6.get());
				tabData.accept(OliverModItems.T_90.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(OliverModItems.RT_HELMET.get());
			tabData.accept(OliverModItems.RT_CHESTPLATE.get());
			tabData.accept(OliverModItems.RT_LEGGINGS.get());
			tabData.accept(OliverModItems.RT_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(OliverModItems.DUMMY_SPAWN_EGG.get());
			tabData.accept(OliverModItems.DUMMY_1_SPAWN_EGG.get());
			tabData.accept(OliverModItems.SLIME_SPAWN_EGG.get());
			tabData.accept(OliverModItems.SIMERED_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(OliverModBlocks.BLUEBERRIES.get().asItem());
		}
	}
}
