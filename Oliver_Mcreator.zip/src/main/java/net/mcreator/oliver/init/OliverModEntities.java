
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliver.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.oliver.entity.XEntity;
import net.mcreator.oliver.entity.SlimeEntity;
import net.mcreator.oliver.entity.SimeredEntity;
import net.mcreator.oliver.entity.DummyEntity;
import net.mcreator.oliver.entity.Dummy1Entity;
import net.mcreator.oliver.OliverMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OliverModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, OliverMod.MODID);
	public static final RegistryObject<EntityType<XEntity>> X = register("x",
			EntityType.Builder.<XEntity>of(XEntity::new, MobCategory.MISC).setCustomClientFactory(XEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<DummyEntity>> DUMMY = register("dummy",
			EntityType.Builder.<DummyEntity>of(DummyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(72).setUpdateInterval(3).setCustomClientFactory(DummyEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<Dummy1Entity>> DUMMY_1 = register("dummy_1",
			EntityType.Builder.<Dummy1Entity>of(Dummy1Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Dummy1Entity::new)

					.sized(2f, 4.2f));
	public static final RegistryObject<EntityType<SlimeEntity>> SLIME = register("slime",
			EntityType.Builder.<SlimeEntity>of(SlimeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SlimeEntity::new)

					.sized(1.1f, 2f));
	public static final RegistryObject<EntityType<SimeredEntity>> SIMERED = register("simered",
			EntityType.Builder.<SimeredEntity>of(SimeredEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SimeredEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DummyEntity.init();
			Dummy1Entity.init();
			SlimeEntity.init();
			SimeredEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DUMMY.get(), DummyEntity.createAttributes().build());
		event.put(DUMMY_1.get(), Dummy1Entity.createAttributes().build());
		event.put(SLIME.get(), SlimeEntity.createAttributes().build());
		event.put(SIMERED.get(), SimeredEntity.createAttributes().build());
	}
}
