
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliver.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.oliver.block.RedoreBlock;
import net.mcreator.oliver.block.DBlock;
import net.mcreator.oliver.block.BlueberriesBlock;
import net.mcreator.oliver.OliverMod;

public class OliverModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OliverMod.MODID);
	public static final RegistryObject<Block> REDORE = REGISTRY.register("redore", () -> new RedoreBlock());
	public static final RegistryObject<Block> D = REGISTRY.register("d", () -> new DBlock());
	public static final RegistryObject<Block> BLUEBERRIES = REGISTRY.register("blueberries", () -> new BlueberriesBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
