
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliver.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.oliver.client.renderer.SlimeRenderer;
import net.mcreator.oliver.client.renderer.SimeredRenderer;
import net.mcreator.oliver.client.renderer.DummyRenderer;
import net.mcreator.oliver.client.renderer.Dummy1Renderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class OliverModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(OliverModEntities.X.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(OliverModEntities.DUMMY.get(), DummyRenderer::new);
		event.registerEntityRenderer(OliverModEntities.DUMMY_1.get(), Dummy1Renderer::new);
		event.registerEntityRenderer(OliverModEntities.SLIME.get(), SlimeRenderer::new);
		event.registerEntityRenderer(OliverModEntities.SIMERED.get(), SimeredRenderer::new);
	}
}
