
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliver.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.oliver.item.XitemItem;
import net.mcreator.oliver.item.ToolItem;
import net.mcreator.oliver.item.T90Item;
import net.mcreator.oliver.item.T8Item;
import net.mcreator.oliver.item.T6Item;
import net.mcreator.oliver.item.T4Item;
import net.mcreator.oliver.item.RtItem;
import net.mcreator.oliver.item.RedswordItem;
import net.mcreator.oliver.item.RedstuffItem;
import net.mcreator.oliver.item.AItem;
import net.mcreator.oliver.OliverMod;

public class OliverModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OliverMod.MODID);
	public static final RegistryObject<Item> REDORE = block(OliverModBlocks.REDORE);
	public static final RegistryObject<Item> REDSTUFF = REGISTRY.register("redstuff", () -> new RedstuffItem());
	public static final RegistryObject<Item> REDSWORD = REGISTRY.register("redsword", () -> new RedswordItem());
	public static final RegistryObject<Item> TOOL = REGISTRY.register("tool", () -> new ToolItem());
	public static final RegistryObject<Item> A_HELMET = REGISTRY.register("a_helmet", () -> new AItem.Helmet());
	public static final RegistryObject<Item> A_CHESTPLATE = REGISTRY.register("a_chestplate", () -> new AItem.Chestplate());
	public static final RegistryObject<Item> A_LEGGINGS = REGISTRY.register("a_leggings", () -> new AItem.Leggings());
	public static final RegistryObject<Item> A_BOOTS = REGISTRY.register("a_boots", () -> new AItem.Boots());
	public static final RegistryObject<Item> D = block(OliverModBlocks.D);
	public static final RegistryObject<Item> RT_HELMET = REGISTRY.register("rt_helmet", () -> new RtItem.Helmet());
	public static final RegistryObject<Item> RT_CHESTPLATE = REGISTRY.register("rt_chestplate", () -> new RtItem.Chestplate());
	public static final RegistryObject<Item> RT_LEGGINGS = REGISTRY.register("rt_leggings", () -> new RtItem.Leggings());
	public static final RegistryObject<Item> RT_BOOTS = REGISTRY.register("rt_boots", () -> new RtItem.Boots());
	public static final RegistryObject<Item> BLUEBERRIES = block(OliverModBlocks.BLUEBERRIES);
	public static final RegistryObject<Item> XITEM = REGISTRY.register("xitem", () -> new XitemItem());
	public static final RegistryObject<Item> T_4 = REGISTRY.register("t_4", () -> new T4Item());
	public static final RegistryObject<Item> DUMMY_SPAWN_EGG = REGISTRY.register("dummy_spawn_egg", () -> new ForgeSpawnEggItem(OliverModEntities.DUMMY, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> T_8 = REGISTRY.register("t_8", () -> new T8Item());
	public static final RegistryObject<Item> T_6 = REGISTRY.register("t_6", () -> new T6Item());
	public static final RegistryObject<Item> T_90 = REGISTRY.register("t_90", () -> new T90Item());
	public static final RegistryObject<Item> DUMMY_1_SPAWN_EGG = REGISTRY.register("dummy_1_spawn_egg", () -> new ForgeSpawnEggItem(OliverModEntities.DUMMY_1, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> SLIME_SPAWN_EGG = REGISTRY.register("slime_spawn_egg", () -> new ForgeSpawnEggItem(OliverModEntities.SLIME, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> SIMERED_SPAWN_EGG = REGISTRY.register("simered_spawn_egg", () -> new ForgeSpawnEggItem(OliverModEntities.SIMERED, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
