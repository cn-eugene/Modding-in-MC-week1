
package net.mcreator.thomastorresmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DeadskinItem extends Item {
	public DeadskinItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
