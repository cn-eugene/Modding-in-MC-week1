
package net.mcreator.thomastorresmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CalamitypowderItem extends Item {
	public CalamitypowderItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
