
package net.mcreator.thomastorresmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.thomastorresmod.entity.MeowmeowEntity;

public class MeowmeowRenderer extends HumanoidMobRenderer<MeowmeowEntity, HumanoidModel<MeowmeowEntity>> {
	public MeowmeowRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(MeowmeowEntity entity) {
		return new ResourceLocation("thomastorres_mod:textures/entities/6a73458b42f7b3374f8d8037d3195a9ab06413e8.png");
	}
}
