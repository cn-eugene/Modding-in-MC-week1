
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thomastorresmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.thomastorresmod.item.TotemofthenightItem;
import net.mcreator.thomastorresmod.item.SwordofironItem;
import net.mcreator.thomastorresmod.item.SwordofcalamityItem;
import net.mcreator.thomastorresmod.item.StickItem;
import net.mcreator.thomastorresmod.item.RubickscubearmorItem;
import net.mcreator.thomastorresmod.item.OddItem;
import net.mcreator.thomastorresmod.item.IngotofironItem;
import net.mcreator.thomastorresmod.item.EmroldgemItem;
import net.mcreator.thomastorresmod.item.DeadskinItem;
import net.mcreator.thomastorresmod.item.CrispyfaceItem;
import net.mcreator.thomastorresmod.item.CookedfaceItem;
import net.mcreator.thomastorresmod.item.CalamitystarItem;
import net.mcreator.thomastorresmod.item.CalamitypowderItem;
import net.mcreator.thomastorresmod.item.ArmorofcalamityItem;
import net.mcreator.thomastorresmod.ThomastorresModMod;

public class ThomastorresModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ThomastorresModMod.MODID);
	public static final RegistryObject<Item> WOOD = block(ThomastorresModModBlocks.WOOD);
	public static final RegistryObject<Item> GRASS = block(ThomastorresModModBlocks.GRASS);
	public static final RegistryObject<Item> DIRT = block(ThomastorresModModBlocks.DIRT);
	public static final RegistryObject<Item> COAL = block(ThomastorresModModBlocks.COAL);
	public static final RegistryObject<Item> STONEIRONE = block(ThomastorresModModBlocks.STONEIRONE);
	public static final RegistryObject<Item> INGOTOFIRON = REGISTRY.register("ingotofiron", () -> new IngotofironItem());
	public static final RegistryObject<Item> EMROLD = block(ThomastorresModModBlocks.EMROLD);
	public static final RegistryObject<Item> EMROLDGEM = REGISTRY.register("emroldgem", () -> new EmroldgemItem());
	public static final RegistryObject<Item> SWORDOFIRON = REGISTRY.register("swordofiron", () -> new SwordofironItem());
	public static final RegistryObject<Item> STICK = REGISTRY.register("stick", () -> new StickItem());
	public static final RegistryObject<Item> RUBICKS_3X_3 = block(ThomastorresModModBlocks.RUBICKS_3X_3);
	public static final RegistryObject<Item> RUBICKS_2X_2 = block(ThomastorresModModBlocks.RUBICKS_2X_2);
	public static final RegistryObject<Item> RUBICKS_1X_1 = block(ThomastorresModModBlocks.RUBICKS_1X_1);
	public static final RegistryObject<Item> RUBICKSCUBEARMOR_HELMET = REGISTRY.register("rubickscubearmor_helmet", () -> new RubickscubearmorItem.Helmet());
	public static final RegistryObject<Item> RUBICKSCUBEARMOR_CHESTPLATE = REGISTRY.register("rubickscubearmor_chestplate", () -> new RubickscubearmorItem.Chestplate());
	public static final RegistryObject<Item> RUBICKSCUBEARMOR_LEGGINGS = REGISTRY.register("rubickscubearmor_leggings", () -> new RubickscubearmorItem.Leggings());
	public static final RegistryObject<Item> RUBICKSCUBEARMOR_BOOTS = REGISTRY.register("rubickscubearmor_boots", () -> new RubickscubearmorItem.Boots());
	public static final RegistryObject<Item> SWORDOFCALAMITY = REGISTRY.register("swordofcalamity", () -> new SwordofcalamityItem());
	public static final RegistryObject<Item> ARMOROFCALAMITY_HELMET = REGISTRY.register("armorofcalamity_helmet", () -> new ArmorofcalamityItem.Helmet());
	public static final RegistryObject<Item> ARMOROFCALAMITY_CHESTPLATE = REGISTRY.register("armorofcalamity_chestplate", () -> new ArmorofcalamityItem.Chestplate());
	public static final RegistryObject<Item> ARMOROFCALAMITY_LEGGINGS = REGISTRY.register("armorofcalamity_leggings", () -> new ArmorofcalamityItem.Leggings());
	public static final RegistryObject<Item> ARMOROFCALAMITY_BOOTS = REGISTRY.register("armorofcalamity_boots", () -> new ArmorofcalamityItem.Boots());
	public static final RegistryObject<Item> CALAMITYSTAR = REGISTRY.register("calamitystar", () -> new CalamitystarItem());
	public static final RegistryObject<Item> CALAMITYPOWDER = REGISTRY.register("calamitypowder", () -> new CalamitypowderItem());
	public static final RegistryObject<Item> TOTEMOFTHENIGHT = REGISTRY.register("totemofthenight", () -> new TotemofthenightItem());
	public static final RegistryObject<Item> DEMONOFTHENIGHT_SPAWN_EGG = REGISTRY.register("demonofthenight_spawn_egg", () -> new ForgeSpawnEggItem(ThomastorresModModEntities.DEMONOFTHENIGHT, -65536, -6710887, new Item.Properties()));
	public static final RegistryObject<Item> EDIBLEFACE = block(ThomastorresModModBlocks.EDIBLEFACE);
	public static final RegistryObject<Item> EDIBLE = block(ThomastorresModModBlocks.EDIBLE);
	public static final RegistryObject<Item> MEOWMEOW_SPAWN_EGG = REGISTRY.register("meowmeow_spawn_egg", () -> new ForgeSpawnEggItem(ThomastorresModModEntities.MEOWMEOW, -16711732, -16763956, new Item.Properties()));
	public static final RegistryObject<Item> DEADSKIN = REGISTRY.register("deadskin", () -> new DeadskinItem());
	public static final RegistryObject<Item> COOKEDFACE = REGISTRY.register("cookedface", () -> new CookedfaceItem());
	public static final RegistryObject<Item> CRISPYFACE = REGISTRY.register("crispyface", () -> new CrispyfaceItem());
	public static final RegistryObject<Item> ODDBLOCK = block(ThomastorresModModBlocks.ODDBLOCK);
	public static final RegistryObject<Item> DEMON = block(ThomastorresModModBlocks.DEMON);
	public static final RegistryObject<Item> ODD = REGISTRY.register("odd", () -> new OddItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
