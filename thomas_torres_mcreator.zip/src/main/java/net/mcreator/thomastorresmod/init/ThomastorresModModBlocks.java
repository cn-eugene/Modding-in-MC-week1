
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thomastorresmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.thomastorresmod.block.WoodBlock;
import net.mcreator.thomastorresmod.block.StoneironeBlock;
import net.mcreator.thomastorresmod.block.Rubicks3x3Block;
import net.mcreator.thomastorresmod.block.Rubicks2x2Block;
import net.mcreator.thomastorresmod.block.Rubicks1x1Block;
import net.mcreator.thomastorresmod.block.OddblockBlock;
import net.mcreator.thomastorresmod.block.OddPortalBlock;
import net.mcreator.thomastorresmod.block.GrassBlock;
import net.mcreator.thomastorresmod.block.EmroldBlock;
import net.mcreator.thomastorresmod.block.EdiblefaceBlock;
import net.mcreator.thomastorresmod.block.EdibleBlock;
import net.mcreator.thomastorresmod.block.DirtBlock;
import net.mcreator.thomastorresmod.block.DemonBlock;
import net.mcreator.thomastorresmod.block.CoalBlock;
import net.mcreator.thomastorresmod.ThomastorresModMod;

public class ThomastorresModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ThomastorresModMod.MODID);
	public static final RegistryObject<Block> WOOD = REGISTRY.register("wood", () -> new WoodBlock());
	public static final RegistryObject<Block> GRASS = REGISTRY.register("grass", () -> new GrassBlock());
	public static final RegistryObject<Block> DIRT = REGISTRY.register("dirt", () -> new DirtBlock());
	public static final RegistryObject<Block> COAL = REGISTRY.register("coal", () -> new CoalBlock());
	public static final RegistryObject<Block> STONEIRONE = REGISTRY.register("stoneirone", () -> new StoneironeBlock());
	public static final RegistryObject<Block> EMROLD = REGISTRY.register("emrold", () -> new EmroldBlock());
	public static final RegistryObject<Block> RUBICKS_3X_3 = REGISTRY.register("rubicks_3x_3", () -> new Rubicks3x3Block());
	public static final RegistryObject<Block> RUBICKS_2X_2 = REGISTRY.register("rubicks_2x_2", () -> new Rubicks2x2Block());
	public static final RegistryObject<Block> RUBICKS_1X_1 = REGISTRY.register("rubicks_1x_1", () -> new Rubicks1x1Block());
	public static final RegistryObject<Block> EDIBLEFACE = REGISTRY.register("edibleface", () -> new EdiblefaceBlock());
	public static final RegistryObject<Block> EDIBLE = REGISTRY.register("edible", () -> new EdibleBlock());
	public static final RegistryObject<Block> ODDBLOCK = REGISTRY.register("oddblock", () -> new OddblockBlock());
	public static final RegistryObject<Block> DEMON = REGISTRY.register("demon", () -> new DemonBlock());
	public static final RegistryObject<Block> ODD_PORTAL = REGISTRY.register("odd_portal", () -> new OddPortalBlock());
}
