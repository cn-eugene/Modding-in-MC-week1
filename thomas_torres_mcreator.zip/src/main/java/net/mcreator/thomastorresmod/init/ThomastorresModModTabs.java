
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thomastorresmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.thomastorresmod.ThomastorresModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ThomastorresModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ThomastorresModMod.MODID);
	public static final RegistryObject<CreativeModeTab> CRIMSON = REGISTRY.register("crimson",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.thomastorres_mod.crimson")).icon(() -> new ItemStack(ThomastorresModModBlocks.RUBICKS_3X_3.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ThomastorresModModBlocks.RUBICKS_3X_3.get().asItem());
				tabData.accept(ThomastorresModModBlocks.RUBICKS_2X_2.get().asItem());
				tabData.accept(ThomastorresModModBlocks.RUBICKS_1X_1.get().asItem());
				tabData.accept(ThomastorresModModItems.RUBICKSCUBEARMOR_HELMET.get());
				tabData.accept(ThomastorresModModItems.RUBICKSCUBEARMOR_CHESTPLATE.get());
				tabData.accept(ThomastorresModModItems.RUBICKSCUBEARMOR_LEGGINGS.get());
				tabData.accept(ThomastorresModModItems.RUBICKSCUBEARMOR_BOOTS.get());
				tabData.accept(ThomastorresModModItems.SWORDOFCALAMITY.get());
				tabData.accept(ThomastorresModModItems.ARMOROFCALAMITY_HELMET.get());
				tabData.accept(ThomastorresModModItems.ARMOROFCALAMITY_CHESTPLATE.get());
				tabData.accept(ThomastorresModModItems.ARMOROFCALAMITY_LEGGINGS.get());
				tabData.accept(ThomastorresModModItems.ARMOROFCALAMITY_BOOTS.get());
				tabData.accept(ThomastorresModModItems.CALAMITYSTAR.get());
				tabData.accept(ThomastorresModModItems.CALAMITYPOWDER.get());
				tabData.accept(ThomastorresModModItems.TOTEMOFTHENIGHT.get());
				tabData.accept(ThomastorresModModBlocks.EDIBLEFACE.get().asItem());
				tabData.accept(ThomastorresModModBlocks.EDIBLE.get().asItem());
				tabData.accept(ThomastorresModModItems.DEADSKIN.get());
				tabData.accept(ThomastorresModModItems.COOKEDFACE.get());
				tabData.accept(ThomastorresModModItems.CRISPYFACE.get());
				tabData.accept(ThomastorresModModBlocks.ODDBLOCK.get().asItem());
				tabData.accept(ThomastorresModModBlocks.DEMON.get().asItem());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ThomastorresModModItems.SWORDOFIRON.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ThomastorresModModItems.DEMONOFTHENIGHT_SPAWN_EGG.get());
			tabData.accept(ThomastorresModModItems.MEOWMEOW_SPAWN_EGG.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ThomastorresModModItems.INGOTOFIRON.get());
			tabData.accept(ThomastorresModModItems.EMROLDGEM.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ThomastorresModModBlocks.WOOD.get().asItem());
			tabData.accept(ThomastorresModModBlocks.GRASS.get().asItem());
			tabData.accept(ThomastorresModModBlocks.DIRT.get().asItem());
			tabData.accept(ThomastorresModModBlocks.COAL.get().asItem());
			tabData.accept(ThomastorresModModBlocks.EMROLD.get().asItem());
			tabData.accept(ThomastorresModModItems.STICK.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ThomastorresModModItems.ODD.get());
		}
	}
}
