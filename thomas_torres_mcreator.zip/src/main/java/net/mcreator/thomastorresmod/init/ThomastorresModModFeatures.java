
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thomastorresmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.thomastorresmod.world.features.ores.WoodFeature;
import net.mcreator.thomastorresmod.world.features.ores.StoneironeFeature;
import net.mcreator.thomastorresmod.world.features.ores.GrassFeature;
import net.mcreator.thomastorresmod.world.features.ores.CoalFeature;
import net.mcreator.thomastorresmod.ThomastorresModMod;

@Mod.EventBusSubscriber
public class ThomastorresModModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, ThomastorresModMod.MODID);
	public static final RegistryObject<Feature<?>> WOOD = REGISTRY.register("wood", WoodFeature::new);
	public static final RegistryObject<Feature<?>> GRASS = REGISTRY.register("grass", GrassFeature::new);
	public static final RegistryObject<Feature<?>> COAL = REGISTRY.register("coal", CoalFeature::new);
	public static final RegistryObject<Feature<?>> STONEIRONE = REGISTRY.register("stoneirone", StoneironeFeature::new);
}
