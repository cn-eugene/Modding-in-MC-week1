
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thomastorresmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.thomastorresmod.entity.MeowmeowEntity;
import net.mcreator.thomastorresmod.entity.DemonofthenightEntity;
import net.mcreator.thomastorresmod.entity.CalamitystarEntity;
import net.mcreator.thomastorresmod.ThomastorresModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ThomastorresModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ThomastorresModMod.MODID);
	public static final RegistryObject<EntityType<CalamitystarEntity>> CALAMITYSTAR = register("projectile_calamitystar",
			EntityType.Builder.<CalamitystarEntity>of(CalamitystarEntity::new, MobCategory.MISC).setCustomClientFactory(CalamitystarEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<DemonofthenightEntity>> DEMONOFTHENIGHT = register("demonofthenight",
			EntityType.Builder.<DemonofthenightEntity>of(DemonofthenightEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DemonofthenightEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<MeowmeowEntity>> MEOWMEOW = register("meowmeow",
			EntityType.Builder.<MeowmeowEntity>of(MeowmeowEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MeowmeowEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DemonofthenightEntity.init();
			MeowmeowEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DEMONOFTHENIGHT.get(), DemonofthenightEntity.createAttributes().build());
		event.put(MEOWMEOW.get(), MeowmeowEntity.createAttributes().build());
	}
}
