
package net.mcreator.johnmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PsychicIngotItem extends Item {
	public PsychicIngotItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
