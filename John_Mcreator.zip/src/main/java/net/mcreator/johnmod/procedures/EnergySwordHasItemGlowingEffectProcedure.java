package net.mcreator.johnmod.procedures;

public class EnergySwordHasItemGlowingEffectProcedure {
	public static void execute() {
	}
}
