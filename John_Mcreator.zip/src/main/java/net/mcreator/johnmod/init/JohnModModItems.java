
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.johnmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.johnmod.item.PsychicItem;
import net.mcreator.johnmod.item.PsychicIngotItem;
import net.mcreator.johnmod.item.GunItem;
import net.mcreator.johnmod.item.EnergySwordItem;
import net.mcreator.johnmod.item.EnergyPickaxeItem;
import net.mcreator.johnmod.JohnModMod;

public class JohnModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, JohnModMod.MODID);
	public static final RegistryObject<Item> ENERGY_SWORD = REGISTRY.register("energy_sword", () -> new EnergySwordItem());
	public static final RegistryObject<Item> GUN = REGISTRY.register("gun", () -> new GunItem());
	public static final RegistryObject<Item> PSYCHIC_ORE = block(JohnModModBlocks.PSYCHIC_ORE);
	public static final RegistryObject<Item> PSYCHIC_INGOT = REGISTRY.register("psychic_ingot", () -> new PsychicIngotItem());
	public static final RegistryObject<Item> ENERGY_PICKAXE = REGISTRY.register("energy_pickaxe", () -> new EnergyPickaxeItem());
	public static final RegistryObject<Item> PSYCHIC_HELMET = REGISTRY.register("psychic_helmet", () -> new PsychicItem.Helmet());
	public static final RegistryObject<Item> PSYCHIC_CHESTPLATE = REGISTRY.register("psychic_chestplate", () -> new PsychicItem.Chestplate());
	public static final RegistryObject<Item> PSYCHIC_LEGGINGS = REGISTRY.register("psychic_leggings", () -> new PsychicItem.Leggings());
	public static final RegistryObject<Item> PSYCHIC_BOOTS = REGISTRY.register("psychic_boots", () -> new PsychicItem.Boots());
	public static final RegistryObject<Item> SKEKELTON_SPAWN_EGG = REGISTRY.register("skekelton_spawn_egg", () -> new ForgeSpawnEggItem(JohnModModEntities.SKEKELTON, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
