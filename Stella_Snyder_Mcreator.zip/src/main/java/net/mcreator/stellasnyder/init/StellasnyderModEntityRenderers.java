
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stellasnyder.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.stellasnyder.client.renderer.OllieRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class StellasnyderModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(StellasnyderModEntities.RAINBOWSTAR_22.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(StellasnyderModEntities.OLLIE.get(), OllieRenderer::new);
	}
}
