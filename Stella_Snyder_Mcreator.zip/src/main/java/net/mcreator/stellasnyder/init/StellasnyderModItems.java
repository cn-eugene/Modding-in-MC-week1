
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stellasnyder.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.stellasnyder.item.RainbowstarItem;
import net.mcreator.stellasnyder.item.RainbowshovelItem;
import net.mcreator.stellasnyder.item.RainbowpickaxeItem;
import net.mcreator.stellasnyder.item.RainbowingotItem;
import net.mcreator.stellasnyder.item.RainbowhoeItem;
import net.mcreator.stellasnyder.item.RainbowaxeItem;
import net.mcreator.stellasnyder.item.Rainbowarmor22Item;
import net.mcreator.stellasnyder.item.RAINBOWSOARDItem;
import net.mcreator.stellasnyder.StellasnyderMod;

public class StellasnyderModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, StellasnyderMod.MODID);
	public static final RegistryObject<Item> RAINBOW = block(StellasnyderModBlocks.RAINBOW);
	public static final RegistryObject<Item> RAINBOWORE = block(StellasnyderModBlocks.RAINBOWORE);
	public static final RegistryObject<Item> RAINBOWINGOT = REGISTRY.register("rainbowingot", () -> new RainbowingotItem());
	public static final RegistryObject<Item> RAINBOWSOARD = REGISTRY.register("rainbowsoard", () -> new RAINBOWSOARDItem());
	public static final RegistryObject<Item> RAINBOWPICKAXE = REGISTRY.register("rainbowpickaxe", () -> new RainbowpickaxeItem());
	public static final RegistryObject<Item> RAINBOWAXE = REGISTRY.register("rainbowaxe", () -> new RainbowaxeItem());
	public static final RegistryObject<Item> RAINBOWSHOVEL = REGISTRY.register("rainbowshovel", () -> new RainbowshovelItem());
	public static final RegistryObject<Item> RAINBOWHOE = REGISTRY.register("rainbowhoe", () -> new RainbowhoeItem());
	public static final RegistryObject<Item> RAINBOWARMOR_22_HELMET = REGISTRY.register("rainbowarmor_22_helmet", () -> new Rainbowarmor22Item.Helmet());
	public static final RegistryObject<Item> RAINBOWARMOR_22_CHESTPLATE = REGISTRY.register("rainbowarmor_22_chestplate", () -> new Rainbowarmor22Item.Chestplate());
	public static final RegistryObject<Item> RAINBOWARMOR_22_LEGGINGS = REGISTRY.register("rainbowarmor_22_leggings", () -> new Rainbowarmor22Item.Leggings());
	public static final RegistryObject<Item> RAINBOWARMOR_22_BOOTS = REGISTRY.register("rainbowarmor_22_boots", () -> new Rainbowarmor22Item.Boots());
	public static final RegistryObject<Item> RAINBOWSTAR = REGISTRY.register("rainbowstar", () -> new RainbowstarItem());
	public static final RegistryObject<Item> OLLIE_SPAWN_EGG = REGISTRY.register("ollie_spawn_egg", () -> new ForgeSpawnEggItem(StellasnyderModEntities.OLLIE, -1, -16737895, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
