
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stellasnyder.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.stellasnyder.block.RainboworeBlock;
import net.mcreator.stellasnyder.block.RainbowBlock;
import net.mcreator.stellasnyder.StellasnyderMod;

public class StellasnyderModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, StellasnyderMod.MODID);
	public static final RegistryObject<Block> RAINBOW = REGISTRY.register("rainbow", () -> new RainbowBlock());
	public static final RegistryObject<Block> RAINBOWORE = REGISTRY.register("rainbowore", () -> new RainboworeBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
