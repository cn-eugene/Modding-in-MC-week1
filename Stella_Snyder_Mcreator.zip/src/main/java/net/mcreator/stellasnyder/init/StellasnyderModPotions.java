
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stellasnyder.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.stellasnyder.StellasnyderMod;

public class StellasnyderModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, StellasnyderMod.MODID);
	public static final RegistryObject<Potion> RAINBOWPOTION = REGISTRY.register("rainbowpotion", () -> new Potion(new MobEffectInstance(MobEffects.JUMP, 3600, 0, false, false)));
	public static final RegistryObject<Potion> GLITCHPOTION = REGISTRY.register("glitchpotion", () -> new Potion());
}
