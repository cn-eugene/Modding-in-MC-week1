
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.stellasnyder.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.stellasnyder.StellasnyderMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class StellasnyderModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, StellasnyderMod.MODID);
	public static final RegistryObject<CreativeModeTab> RAINBOWMOD_3 = REGISTRY.register("rainbowmod_3",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.stellasnyder.rainbowmod_3")).icon(() -> new ItemStack(StellasnyderModItems.RAINBOWSOARD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(StellasnyderModBlocks.RAINBOWORE.get().asItem());
				tabData.accept(StellasnyderModBlocks.RAINBOW.get().asItem());
				tabData.accept(StellasnyderModItems.RAINBOWINGOT.get());
				tabData.accept(StellasnyderModItems.RAINBOWSOARD.get());
				tabData.accept(StellasnyderModItems.RAINBOWPICKAXE.get());
				tabData.accept(StellasnyderModItems.RAINBOWAXE.get());
				tabData.accept(StellasnyderModItems.RAINBOWSHOVEL.get());
				tabData.accept(StellasnyderModItems.RAINBOWHOE.get());
				tabData.accept(StellasnyderModItems.RAINBOWARMOR_22_HELMET.get());
				tabData.accept(StellasnyderModItems.RAINBOWARMOR_22_CHESTPLATE.get());
				tabData.accept(StellasnyderModItems.RAINBOWARMOR_22_LEGGINGS.get());
				tabData.accept(StellasnyderModItems.RAINBOWARMOR_22_BOOTS.get());
				tabData.accept(StellasnyderModItems.RAINBOWSTAR.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(StellasnyderModItems.OLLIE_SPAWN_EGG.get());
		}
	}
}
