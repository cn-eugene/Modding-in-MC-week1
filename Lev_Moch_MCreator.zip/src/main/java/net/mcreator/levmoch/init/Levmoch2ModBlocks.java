
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levmoch.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.levmoch.block.HltoreBlock;
import net.mcreator.levmoch.block.HltdemPortalBlock;
import net.mcreator.levmoch.block.HltPcBlock;
import net.mcreator.levmoch.block.HBlock;
import net.mcreator.levmoch.Levmoch2Mod;

public class Levmoch2ModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, Levmoch2Mod.MODID);
	public static final RegistryObject<Block> H = REGISTRY.register("h", () -> new HBlock());
	public static final RegistryObject<Block> HLTORE = REGISTRY.register("hltore", () -> new HltoreBlock());
	public static final RegistryObject<Block> HLTDEM_PORTAL = REGISTRY.register("hltdem_portal", () -> new HltdemPortalBlock());
	public static final RegistryObject<Block> HLT_PC = REGISTRY.register("hlt_pc", () -> new HltPcBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
