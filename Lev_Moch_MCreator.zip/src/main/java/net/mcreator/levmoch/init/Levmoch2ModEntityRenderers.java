
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levmoch.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.levmoch.client.renderer.Hltmob7Renderer;
import net.mcreator.levmoch.client.renderer.GreenboiRenderer;
import net.mcreator.levmoch.client.renderer.DragonKnight9Renderer;
import net.mcreator.levmoch.client.renderer.AsdfghRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class Levmoch2ModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(Levmoch2ModEntities.LIGHTNING.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(Levmoch2ModEntities.DRAGON_KNIGHT_9.get(), DragonKnight9Renderer::new);
		event.registerEntityRenderer(Levmoch2ModEntities.HLTMOB_7.get(), Hltmob7Renderer::new);
		event.registerEntityRenderer(Levmoch2ModEntities.GREENBOI.get(), GreenboiRenderer::new);
		event.registerEntityRenderer(Levmoch2ModEntities.ASDFGH.get(), AsdfghRenderer::new);
	}
}
