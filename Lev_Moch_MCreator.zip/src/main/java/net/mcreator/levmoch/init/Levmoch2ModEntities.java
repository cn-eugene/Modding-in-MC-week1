
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levmoch.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.levmoch.entity.LightningEntity;
import net.mcreator.levmoch.entity.Hltmob7Entity;
import net.mcreator.levmoch.entity.GreenboiEntity;
import net.mcreator.levmoch.entity.DragonKnight9Entity;
import net.mcreator.levmoch.entity.AsdfghEntity;
import net.mcreator.levmoch.Levmoch2Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class Levmoch2ModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Levmoch2Mod.MODID);
	public static final RegistryObject<EntityType<LightningEntity>> LIGHTNING = register("lightning",
			EntityType.Builder.<LightningEntity>of(LightningEntity::new, MobCategory.MISC).setCustomClientFactory(LightningEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<DragonKnight9Entity>> DRAGON_KNIGHT_9 = register("dragon_knight_9",
			EntityType.Builder.<DragonKnight9Entity>of(DragonKnight9Entity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DragonKnight9Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<Hltmob7Entity>> HLTMOB_7 = register("hltmob_7",
			EntityType.Builder.<Hltmob7Entity>of(Hltmob7Entity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Hltmob7Entity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GreenboiEntity>> GREENBOI = register("greenboi",
			EntityType.Builder.<GreenboiEntity>of(GreenboiEntity::new, MobCategory.AMBIENT).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GreenboiEntity::new).fireImmune().sized(0.4f, 0.7f));
	public static final RegistryObject<EntityType<AsdfghEntity>> ASDFGH = register("asdfgh",
			EntityType.Builder.<AsdfghEntity>of(AsdfghEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AsdfghEntity::new)

					.sized(0.6f, 1.95f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DragonKnight9Entity.init();
			Hltmob7Entity.init();
			GreenboiEntity.init();
			AsdfghEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DRAGON_KNIGHT_9.get(), DragonKnight9Entity.createAttributes().build());
		event.put(HLTMOB_7.get(), Hltmob7Entity.createAttributes().build());
		event.put(GREENBOI.get(), GreenboiEntity.createAttributes().build());
		event.put(ASDFGH.get(), AsdfghEntity.createAttributes().build());
	}
}
