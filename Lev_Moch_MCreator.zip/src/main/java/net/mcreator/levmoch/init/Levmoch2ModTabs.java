
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levmoch.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.levmoch.Levmoch2Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class Levmoch2ModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Levmoch2Mod.MODID);
	public static final RegistryObject<CreativeModeTab> HLTAB = REGISTRY.register("hltab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.levmoch2.hltab")).icon(() -> new ItemStack(Levmoch2ModBlocks.H.get())).displayItems((parameters, tabData) -> {
				tabData.accept(Levmoch2ModBlocks.H.get().asItem());
				tabData.accept(Levmoch2ModItems.DRAGON_KNIGHT_9_SPAWN_EGG.get());
				tabData.accept(Levmoch2ModItems.HLTMOB_7_SPAWN_EGG.get());
				tabData.accept(Levmoch2ModItems.GREENBOI_SPAWN_EGG.get());
				tabData.accept(Levmoch2ModItems.ASDFGH_SPAWN_EGG.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(Levmoch2ModItems.NUKE.get());
			tabData.accept(Levmoch2ModItems.HLTSWORD.get());
			tabData.accept(Levmoch2ModItems.HLTDEM.get());
			tabData.accept(Levmoch2ModItems.HLTPANTS_HELMET.get());
			tabData.accept(Levmoch2ModItems.HLTPANTS_CHESTPLATE.get());
			tabData.accept(Levmoch2ModItems.HLTPANTS_LEGGINGS.get());
			tabData.accept(Levmoch2ModItems.HLTPANTS_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(Levmoch2ModItems.HLTPICX.get());
			tabData.accept(Levmoch2ModItems.THOR_HAMMER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(Levmoch2ModBlocks.HLTORE.get().asItem());
		}
	}
}
