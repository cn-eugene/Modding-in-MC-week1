
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.levmoch.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.levmoch.item.ThorHammerItem;
import net.mcreator.levmoch.item.NukeItem;
import net.mcreator.levmoch.item.LllllllllliItem;
import net.mcreator.levmoch.item.HltswordItem;
import net.mcreator.levmoch.item.HltpicxItem;
import net.mcreator.levmoch.item.HltpantsItem;
import net.mcreator.levmoch.item.HltgemItem;
import net.mcreator.levmoch.item.HltdemItem;
import net.mcreator.levmoch.Levmoch2Mod;

public class Levmoch2ModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, Levmoch2Mod.MODID);
	public static final RegistryObject<Item> H = block(Levmoch2ModBlocks.H);
	public static final RegistryObject<Item> NUKE = REGISTRY.register("nuke", () -> new NukeItem());
	public static final RegistryObject<Item> HLTGEM = REGISTRY.register("hltgem", () -> new HltgemItem());
	public static final RegistryObject<Item> HLTSWORD = REGISTRY.register("hltsword", () -> new HltswordItem());
	public static final RegistryObject<Item> HLTPICX = REGISTRY.register("hltpicx", () -> new HltpicxItem());
	public static final RegistryObject<Item> HLTORE = block(Levmoch2ModBlocks.HLTORE);
	public static final RegistryObject<Item> HLTDEM = REGISTRY.register("hltdem", () -> new HltdemItem());
	public static final RegistryObject<Item> HLT_PC = block(Levmoch2ModBlocks.HLT_PC);
	public static final RegistryObject<Item> HLTPANTS_HELMET = REGISTRY.register("hltpants_helmet", () -> new HltpantsItem.Helmet());
	public static final RegistryObject<Item> HLTPANTS_CHESTPLATE = REGISTRY.register("hltpants_chestplate", () -> new HltpantsItem.Chestplate());
	public static final RegistryObject<Item> HLTPANTS_LEGGINGS = REGISTRY.register("hltpants_leggings", () -> new HltpantsItem.Leggings());
	public static final RegistryObject<Item> HLTPANTS_BOOTS = REGISTRY.register("hltpants_boots", () -> new HltpantsItem.Boots());
	public static final RegistryObject<Item> THOR_HAMMER = REGISTRY.register("thor_hammer", () -> new ThorHammerItem());
	public static final RegistryObject<Item> LLLLLLLLLLI = REGISTRY.register("lllllllllli", () -> new LllllllllliItem());
	public static final RegistryObject<Item> DRAGON_KNIGHT_9_SPAWN_EGG = REGISTRY.register("dragon_knight_9_spawn_egg", () -> new ForgeSpawnEggItem(Levmoch2ModEntities.DRAGON_KNIGHT_9, -10066330, -16737895, new Item.Properties()));
	public static final RegistryObject<Item> HLTMOB_7_SPAWN_EGG = REGISTRY.register("hltmob_7_spawn_egg", () -> new ForgeSpawnEggItem(Levmoch2ModEntities.HLTMOB_7, -39169, -6684775, new Item.Properties()));
	public static final RegistryObject<Item> GREENBOI_SPAWN_EGG = REGISTRY.register("greenboi_spawn_egg", () -> new ForgeSpawnEggItem(Levmoch2ModEntities.GREENBOI, -16738048, -13421824, new Item.Properties()));
	public static final RegistryObject<Item> ASDFGH_SPAWN_EGG = REGISTRY.register("asdfgh_spawn_egg", () -> new ForgeSpawnEggItem(Levmoch2ModEntities.ASDFGH, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
