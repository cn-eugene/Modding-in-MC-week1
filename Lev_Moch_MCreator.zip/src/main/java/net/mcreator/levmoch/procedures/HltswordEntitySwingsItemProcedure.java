package net.mcreator.levmoch.procedures;

public class HltswordEntitySwingsItemProcedure {
	public static void execute() {
	}
}
