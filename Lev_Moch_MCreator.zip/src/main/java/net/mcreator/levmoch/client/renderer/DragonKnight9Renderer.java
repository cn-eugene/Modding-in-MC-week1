
package net.mcreator.levmoch.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.levmoch.entity.DragonKnight9Entity;

public class DragonKnight9Renderer extends HumanoidMobRenderer<DragonKnight9Entity, HumanoidModel<DragonKnight9Entity>> {
	public DragonKnight9Renderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(DragonKnight9Entity entity) {
		return new ResourceLocation("levmoch2:textures/entities/171206688ddc97b4e2f89848c72645cd48ce958c.png");
	}
}
