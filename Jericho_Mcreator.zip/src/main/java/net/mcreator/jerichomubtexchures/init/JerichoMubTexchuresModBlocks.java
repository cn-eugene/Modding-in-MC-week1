
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jerichomubtexchures.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.jerichomubtexchures.block.Gl1chBlock;
import net.mcreator.jerichomubtexchures.block.CyaneeworldPortalBlock;
import net.mcreator.jerichomubtexchures.block.CyaneeBlock;
import net.mcreator.jerichomubtexchures.block.CreeplBlock;
import net.mcreator.jerichomubtexchures.JerichoMubTexchuresMod;

public class JerichoMubTexchuresModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, JerichoMubTexchuresMod.MODID);
	public static final RegistryObject<Block> CREEPL = REGISTRY.register("creepl", () -> new CreeplBlock());
	public static final RegistryObject<Block> CYANEE = REGISTRY.register("cyanee", () -> new CyaneeBlock());
	public static final RegistryObject<Block> GL_1CH = REGISTRY.register("gl_1ch", () -> new Gl1chBlock());
	public static final RegistryObject<Block> CYANEEWORLD_PORTAL = REGISTRY.register("cyaneeworld_portal", () -> new CyaneeworldPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
