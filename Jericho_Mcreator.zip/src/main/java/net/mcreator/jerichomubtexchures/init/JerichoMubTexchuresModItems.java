
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jerichomubtexchures.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.jerichomubtexchures.item.InffcubeItem;
import net.mcreator.jerichomubtexchures.item.InfcubeItem;
import net.mcreator.jerichomubtexchures.item.Gl1tchingotItem;
import net.mcreator.jerichomubtexchures.item.EeeeeeeeeeeeeeeeeeeItem;
import net.mcreator.jerichomubtexchures.item.CyanlandblastItem;
import net.mcreator.jerichomubtexchures.item.CyaneeworldItem;
import net.mcreator.jerichomubtexchures.item.ByeItem;
import net.mcreator.jerichomubtexchures.JerichoMubTexchuresMod;

public class JerichoMubTexchuresModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, JerichoMubTexchuresMod.MODID);
	public static final RegistryObject<Item> CREEPL = block(JerichoMubTexchuresModBlocks.CREEPL);
	public static final RegistryObject<Item> CYANEE = block(JerichoMubTexchuresModBlocks.CYANEE);
	public static final RegistryObject<Item> INFFCUBE = REGISTRY.register("inffcube", () -> new InffcubeItem());
	public static final RegistryObject<Item> EEEEEEEEEEEEEEEEEEE = REGISTRY.register("eeeeeeeeeeeeeeeeeee", () -> new EeeeeeeeeeeeeeeeeeeItem());
	public static final RegistryObject<Item> INFCUBE = REGISTRY.register("infcube", () -> new InfcubeItem());
	public static final RegistryObject<Item> GL_1CH = block(JerichoMubTexchuresModBlocks.GL_1CH);
	public static final RegistryObject<Item> GL_1TCHINGOT = REGISTRY.register("gl_1tchingot", () -> new Gl1tchingotItem());
	public static final RegistryObject<Item> CYANEEWORLD = REGISTRY.register("cyaneeworld", () -> new CyaneeworldItem());
	public static final RegistryObject<Item> BYE = REGISTRY.register("bye", () -> new ByeItem());
	public static final RegistryObject<Item> CYANLANDBLAST = REGISTRY.register("cyanlandblast", () -> new CyanlandblastItem());
	public static final RegistryObject<Item> CYANEEY_SPAWN_EGG = REGISTRY.register("cyaneey_spawn_egg", () -> new ForgeSpawnEggItem(JerichoMubTexchuresModEntities.CYANEEY, -13369396, -16724788, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
