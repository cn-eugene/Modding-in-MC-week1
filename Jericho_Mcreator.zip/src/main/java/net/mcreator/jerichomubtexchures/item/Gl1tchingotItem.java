
package net.mcreator.jerichomubtexchures.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Gl1tchingotItem extends Item {
	public Gl1tchingotItem() {
		super(new Item.Properties().stacksTo(7).fireResistant().rarity(Rarity.COMMON));
	}
}
