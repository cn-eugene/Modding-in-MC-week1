package net.mcreator.dylanhutchins.procedures;

public class UnspeakableEntityIsHurtProcedure {
	public static void execute() {
	}
}
