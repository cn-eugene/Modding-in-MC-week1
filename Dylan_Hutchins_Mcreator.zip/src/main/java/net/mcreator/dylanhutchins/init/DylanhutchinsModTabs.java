
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dylanhutchins.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.dylanhutchins.DylanhutchinsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class DylanhutchinsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DylanhutchinsMod.MODID);
	public static final RegistryObject<CreativeModeTab> MODS = REGISTRY.register("mods",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.dylanhutchins.mods")).icon(() -> new ItemStack(DylanhutchinsModBlocks.CREEPERBLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DylanhutchinsModItems.GODSWORD.get());
				tabData.accept(DylanhutchinsModBlocks.CREEPERBLOCK.get().asItem());
				tabData.accept(DylanhutchinsModBlocks.ORANGEORE.get().asItem());
				tabData.accept(DylanhutchinsModItems.ORANGEINGOT.get());
				tabData.accept(DylanhutchinsModItems.NOOBSWORD.get());
				tabData.accept(DylanhutchinsModBlocks.NOOBORE.get().asItem());
				tabData.accept(DylanhutchinsModItems.NOOBINGOT.get());
				tabData.accept(DylanhutchinsModItems.NOOB_678.get());
				tabData.accept(DylanhutchinsModItems.NOOB_56.get());
				tabData.accept(DylanhutchinsModBlocks.RAINBOWORE.get().asItem());
				tabData.accept(DylanhutchinsModItems.CREEPERSPAWNEGG.get());
				tabData.accept(DylanhutchinsModItems.RAINBOWINGOT.get());
				tabData.accept(DylanhutchinsModItems.UNSPEAKABLE_5.get());
				tabData.accept(DylanhutchinsModItems.UNSPEAKABLE_SPAWN_EGG.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(DylanhutchinsModItems.NOOB.get());
			tabData.accept(DylanhutchinsModItems.NOOBARMOR_HELMET.get());
			tabData.accept(DylanhutchinsModItems.NOOBARMOR_CHESTPLATE.get());
			tabData.accept(DylanhutchinsModItems.NOOBARMOR_LEGGINGS.get());
			tabData.accept(DylanhutchinsModItems.NOOBARMOR_BOOTS.get());
		}
	}
}
