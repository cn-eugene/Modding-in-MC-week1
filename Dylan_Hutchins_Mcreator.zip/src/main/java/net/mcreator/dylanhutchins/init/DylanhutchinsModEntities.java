
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dylanhutchins.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.dylanhutchins.entity.UnspeakabletongueEntity;
import net.mcreator.dylanhutchins.entity.UnspeakableEntity;
import net.mcreator.dylanhutchins.entity.Noob456Entity;
import net.mcreator.dylanhutchins.DylanhutchinsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class DylanhutchinsModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DylanhutchinsMod.MODID);
	public static final RegistryObject<EntityType<Noob456Entity>> NOOB_456 = register("noob_456",
			EntityType.Builder.<Noob456Entity>of(Noob456Entity::new, MobCategory.MISC).setCustomClientFactory(Noob456Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<UnspeakabletongueEntity>> UNSPEAKABLETONGUE = register("unspeakabletongue", EntityType.Builder.<UnspeakabletongueEntity>of(UnspeakabletongueEntity::new, MobCategory.MISC)
			.setCustomClientFactory(UnspeakabletongueEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<UnspeakableEntity>> UNSPEAKABLE = register("unspeakable",
			EntityType.Builder.<UnspeakableEntity>of(UnspeakableEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(UnspeakableEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			UnspeakableEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(UNSPEAKABLE.get(), UnspeakableEntity.createAttributes().build());
	}
}
