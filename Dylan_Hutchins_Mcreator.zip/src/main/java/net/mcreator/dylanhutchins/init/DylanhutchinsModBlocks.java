
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dylanhutchins.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.dylanhutchins.block.RainboworeBlock;
import net.mcreator.dylanhutchins.block.OrangeoreBlock;
import net.mcreator.dylanhutchins.block.NooboreBlock;
import net.mcreator.dylanhutchins.block.NoobPortalBlock;
import net.mcreator.dylanhutchins.block.CreeperblockBlock;
import net.mcreator.dylanhutchins.DylanhutchinsMod;

public class DylanhutchinsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, DylanhutchinsMod.MODID);
	public static final RegistryObject<Block> CREEPERBLOCK = REGISTRY.register("creeperblock", () -> new CreeperblockBlock());
	public static final RegistryObject<Block> ORANGEORE = REGISTRY.register("orangeore", () -> new OrangeoreBlock());
	public static final RegistryObject<Block> NOOBORE = REGISTRY.register("noobore", () -> new NooboreBlock());
	public static final RegistryObject<Block> NOOB_PORTAL = REGISTRY.register("noob_portal", () -> new NoobPortalBlock());
	public static final RegistryObject<Block> RAINBOWORE = REGISTRY.register("rainbowore", () -> new RainboworeBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
