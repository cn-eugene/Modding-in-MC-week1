
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.dylanhutchins.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.dylanhutchins.item.Unspeakable5Item;
import net.mcreator.dylanhutchins.item.RainbowingotItem;
import net.mcreator.dylanhutchins.item.OrangeingotItem;
import net.mcreator.dylanhutchins.item.NoobswordItem;
import net.mcreator.dylanhutchins.item.NoobingotItem;
import net.mcreator.dylanhutchins.item.NoobarmorItem;
import net.mcreator.dylanhutchins.item.NoobItem;
import net.mcreator.dylanhutchins.item.Noob678Item;
import net.mcreator.dylanhutchins.item.Noob56Item;
import net.mcreator.dylanhutchins.item.GodswordItem;
import net.mcreator.dylanhutchins.item.CreeperspawneggItem;
import net.mcreator.dylanhutchins.DylanhutchinsMod;

public class DylanhutchinsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, DylanhutchinsMod.MODID);
	public static final RegistryObject<Item> CREEPERBLOCK = block(DylanhutchinsModBlocks.CREEPERBLOCK);
	public static final RegistryObject<Item> GODSWORD = REGISTRY.register("godsword", () -> new GodswordItem());
	public static final RegistryObject<Item> ORANGEORE = block(DylanhutchinsModBlocks.ORANGEORE);
	public static final RegistryObject<Item> ORANGEINGOT = REGISTRY.register("orangeingot", () -> new OrangeingotItem());
	public static final RegistryObject<Item> NOOBSWORD = REGISTRY.register("noobsword", () -> new NoobswordItem());
	public static final RegistryObject<Item> NOOBORE = block(DylanhutchinsModBlocks.NOOBORE);
	public static final RegistryObject<Item> NOOBINGOT = REGISTRY.register("noobingot", () -> new NoobingotItem());
	public static final RegistryObject<Item> NOOB = REGISTRY.register("noob", () -> new NoobItem());
	public static final RegistryObject<Item> NOOBARMOR_HELMET = REGISTRY.register("noobarmor_helmet", () -> new NoobarmorItem.Helmet());
	public static final RegistryObject<Item> NOOBARMOR_CHESTPLATE = REGISTRY.register("noobarmor_chestplate", () -> new NoobarmorItem.Chestplate());
	public static final RegistryObject<Item> NOOBARMOR_LEGGINGS = REGISTRY.register("noobarmor_leggings", () -> new NoobarmorItem.Leggings());
	public static final RegistryObject<Item> NOOBARMOR_BOOTS = REGISTRY.register("noobarmor_boots", () -> new NoobarmorItem.Boots());
	public static final RegistryObject<Item> NOOB_678 = REGISTRY.register("noob_678", () -> new Noob678Item());
	public static final RegistryObject<Item> NOOB_56 = REGISTRY.register("noob_56", () -> new Noob56Item());
	public static final RegistryObject<Item> RAINBOWORE = block(DylanhutchinsModBlocks.RAINBOWORE);
	public static final RegistryObject<Item> CREEPERSPAWNEGG = REGISTRY.register("creeperspawnegg", () -> new CreeperspawneggItem());
	public static final RegistryObject<Item> RAINBOWINGOT = REGISTRY.register("rainbowingot", () -> new RainbowingotItem());
	public static final RegistryObject<Item> UNSPEAKABLE_5 = REGISTRY.register("unspeakable_5", () -> new Unspeakable5Item());
	public static final RegistryObject<Item> UNSPEAKABLE_SPAWN_EGG = REGISTRY.register("unspeakable_spawn_egg", () -> new ForgeSpawnEggItem(DylanhutchinsModEntities.UNSPEAKABLE, -16738048, -13369600, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
