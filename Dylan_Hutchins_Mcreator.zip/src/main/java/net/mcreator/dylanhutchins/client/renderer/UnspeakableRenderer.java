
package net.mcreator.dylanhutchins.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.dylanhutchins.entity.UnspeakableEntity;

public class UnspeakableRenderer extends HumanoidMobRenderer<UnspeakableEntity, HumanoidModel<UnspeakableEntity>> {
	public UnspeakableRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(UnspeakableEntity entity) {
		return new ResourceLocation("dylanhutchins:textures/entities/1f688119c4b8737901dea4190983c0558f289d0f.png");
	}
}
