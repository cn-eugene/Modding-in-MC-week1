
package net.mcreator.dylanhutchins.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class OrangeingotItem extends Item {
	public OrangeingotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
